

import javax.servlet.http.*;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f192021 = false;
    public void f192022(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f192021 = true;
        data = f192022_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f192022_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f192021)
        {
            data = ""; 
            {
                Properties properties = new Properties();
                FileInputStream streamFileInput = null;
                try
                {
                    streamFileInput = new FileInputStream("../common/config.properties");
                    properties.load(streamFileInput);
                    data = properties.getProperty("data");
                }
                catch (IOException exceptIO)
                {
                    IO.logger.log(Level.WARNING, "Error with stream reading", exceptIO);
                }
                finally
                {
                    try
                    {
                        if (streamFileInput != null)
                        {
                            streamFileInput.close();
                        }
                    }
                    catch (IOException exceptIO)
                    {
                        IO.logger.log(Level.WARNING, "Error closing FileInputStream", exceptIO);
                    }
                }
            }
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f192029 = false;
    private boolean f192030 = false;
    private String f192031_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f192029)
        {
            data = null;
        }
        else
        {
            data = "foo";
        }
        return data;
    }
    private String f192035_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f192030)
        {
            data = "foo";
        }
        else
        {
            data = null;
        }
        return data;
    }
}