

public class MyClass extends AbstractTestCase
{
    private void f279348() throws Throwable
    {
        if (IO.staticReturnsTrueOrFalse())
        {
            assert true; 
        }
        else
        {
            assert true; 
        }
    }
    public void f279350() throws Throwable
    {
        f279348();
    }
}