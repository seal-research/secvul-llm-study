

public class MyClass extends AbstractTestCase
{
    private void f279674() throws Throwable
    {
        if (IO.staticFalse)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279676 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279676.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279676 = null;
            }
        }
    }
    private void f279679() throws Throwable
    {
        if (IO.staticTrue)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279676 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279676.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279676 = null;
            }
        }
    }
    public void f279684() throws Throwable
    {
        f279674();
        f279679();
    }
}