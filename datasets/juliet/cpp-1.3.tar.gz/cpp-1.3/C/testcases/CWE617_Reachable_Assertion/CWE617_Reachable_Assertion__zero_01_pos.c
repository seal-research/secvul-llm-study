
#include "std_testcase.h"
#include <assert.h>
static void f250399()
{
    assert(1); 
}
void f250398()
{
    f250399();
}
