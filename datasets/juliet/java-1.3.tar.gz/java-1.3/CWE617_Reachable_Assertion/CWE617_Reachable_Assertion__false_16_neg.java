

public class MyClass extends AbstractTestCase
{
    public void f192693() throws Throwable
    {
        while(true)
        {
            assert false; 
            break;
        }
    }
}