
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12209
{
static void f106170(int &data)
{
    data = RAND32();
}
void f106171()
{
    int data;
    data = -1;
    f106170(data);
    assert(data > ASSERT_VALUE);
}
} 
