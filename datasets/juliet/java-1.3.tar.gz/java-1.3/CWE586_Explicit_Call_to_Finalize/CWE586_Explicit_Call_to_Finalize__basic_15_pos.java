

public class MyClass extends AbstractTestCase
{
    private void f279521() throws Throwable
    {
        switch (8)
        {
        case 7:
            IO.writeLine("Benign, fixed string");
            break;
        default:
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279523 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279523.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279523 = null;
            }
            break;
        }
    }
    private void f279526() throws Throwable
    {
        switch (7)
        {
        case 7:
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279523 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279523.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279523 = null;
            }
            break;
        default:
            IO.writeLine("Benign, fixed string");
            break;
        }
    }
    public void f279531() throws Throwable
    {
        f279521();
        f279526();
    }
}