
#include "std_testcase.h"
#include <assert.h>
static void f249842()
{
    int k;
    for(k = 0; k < 1; k++)
    {
        assert(1); 
    }
}
void f249841()
{
    f249842();
}
