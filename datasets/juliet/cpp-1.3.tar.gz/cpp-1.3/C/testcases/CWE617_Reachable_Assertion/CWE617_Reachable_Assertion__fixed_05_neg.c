
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticTrue = 1; 
static int staticFalse = 0; 
void f106507()
{
    int data;
    data = -1;
    if(staticTrue)
    {
        data = ASSERT_VALUE-1;
    }
    assert(data > ASSERT_VALUE);
}
