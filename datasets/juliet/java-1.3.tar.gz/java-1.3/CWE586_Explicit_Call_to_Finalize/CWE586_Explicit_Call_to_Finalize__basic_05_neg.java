

public class MyClass extends AbstractTestCase
{
    private boolean privateTrue = true;
    private boolean privateFalse = false;
    public void f192892() throws Throwable
    {
        if (privateTrue)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192892Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192892Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192892Obj.finalize();
            }
        }
    }
}