
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static int f250038Data;
static int f250039G2BData;
static void f250043()
{
    int data = f250039G2BData;
    assert(data > ASSERT_VALUE);
}
static void f250044()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    f250039G2BData = data;
    f250043();
}
void f250039()
{
    f250044();
}
