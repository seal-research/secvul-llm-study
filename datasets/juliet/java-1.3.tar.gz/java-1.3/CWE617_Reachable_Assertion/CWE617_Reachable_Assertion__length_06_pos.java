

public class MyClass extends AbstractTestCase
{
    private static final int PRIVATE_STATIC_FINAL_FIVE = 5;
    private void f279271() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279273() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE == 5)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279275() throws Throwable
    {
        f279271();
        f279273();
    }
}