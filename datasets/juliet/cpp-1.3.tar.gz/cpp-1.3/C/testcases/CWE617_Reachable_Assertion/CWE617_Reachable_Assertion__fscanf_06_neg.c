
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static const int STATIC_CONST_FIVE = 5;
void f106215()
{
    int data;
    data = -1;
    if(STATIC_CONST_FIVE==5)
    {
        fscanf(stdin, "%d", &data);
    }
    assert(data > ASSERT_VALUE);
}
