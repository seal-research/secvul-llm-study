

public class MyClass extends AbstractTestCase
{
    private static final int PRIVATE_STATIC_FINAL_FIVE = 5;
    private void f279206() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279208() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE == 5)
        {
            assert true; 
        }
    }
    public void f279210() throws Throwable
    {
        f279206();
        f279208();
    }
}