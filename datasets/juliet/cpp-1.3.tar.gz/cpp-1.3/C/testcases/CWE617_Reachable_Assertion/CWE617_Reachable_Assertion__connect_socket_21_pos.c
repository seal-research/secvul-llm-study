
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#include <winsock2.h>
#include <windows.h>
#include <direct.h>
#pragma comment(lib, "ws2_32") 
#define CLOSE_SOCKET closesocket
#else 
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define CLOSE_SOCKET close
#define SOCKET int
#define TCP_PORT 27015
#define IP_ADDRESS "127.0.0.1"
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static int f250219 = 0;
static int f250220 = 0;
static int f250221(int data)
{
    if(f250219)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    return data;
}
static void f250223()
{
    int data;
    data = -1;
    f250219 = 0; 
    data = f250221(data);
    assert(data > ASSERT_VALUE);
}
static int f250226(int data)
{
    if(f250220)
    {
        data = ASSERT_VALUE+1;
    }
    return data;
}
static void f250228()
{
    int data;
    data = -1;
    f250220 = 1; 
    data = f250226(data);
    assert(data > ASSERT_VALUE);
}
void f250218()
{
    f250223();
    f250228();
}
