
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12211
{
void f106217()
{
    int data;
    int &dataRef = data;
    data = -1;
    data = RAND32();
    {
        int data = dataRef;
        assert(data > ASSERT_VALUE);
    }
}
} 
