
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static void f250402()
{
    int data;
    data = -1;
    while(1)
    {
        data = ASSERT_VALUE+1;
        break;
    }
    assert(data > ASSERT_VALUE);
}
void f250401()
{
    f250402();
}
