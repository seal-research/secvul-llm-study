
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106483Sink(int data)
{
    assert(data > ASSERT_VALUE);
}
void f106483()
{
    int data;
    data = -1;
    data = ASSERT_VALUE-1;
    f106483Sink(data);
}
