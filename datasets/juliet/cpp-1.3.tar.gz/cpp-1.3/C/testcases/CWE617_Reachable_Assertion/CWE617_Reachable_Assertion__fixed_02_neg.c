
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106410()
{
    int data;
    data = -1;
    if(1)
    {
        data = ASSERT_VALUE-1;
    }
    assert(data > ASSERT_VALUE);
}
