

public class MyClass extends AbstractTestCase
{
    private void f279288() throws Throwable
    {
        if (IO.staticFive != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279290() throws Throwable
    {
        if (IO.staticFive == 5)
        {
            assert true; 
        }
    }
    public void f279292() throws Throwable
    {
        f279288();
        f279290();
    }
}