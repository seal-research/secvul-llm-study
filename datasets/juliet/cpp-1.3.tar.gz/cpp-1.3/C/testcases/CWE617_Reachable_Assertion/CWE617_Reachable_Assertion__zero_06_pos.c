
#include "std_testcase.h"
#include <assert.h>
static const int STATIC_CONST_FIVE = 5;
static void f250113()
{
    if(STATIC_CONST_FIVE!=5)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f250114()
{
    if(STATIC_CONST_FIVE==5)
    {
        assert(1); 
    }
}
void f250112()
{
    f250113();
    f250114();
}
