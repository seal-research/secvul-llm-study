

public class MyClass extends AbstractTestCase
{
    public void f192809() throws Throwable
    {
        try
        {
            throw new IllegalArgumentException();
        }
        catch(IllegalArgumentException exceptIllegalArgument)
        {
            IO.writeLine("preventing incidental issues");
        }
        finally
        {
            if(true)
            {
                return; 
            }
        }
    }
}