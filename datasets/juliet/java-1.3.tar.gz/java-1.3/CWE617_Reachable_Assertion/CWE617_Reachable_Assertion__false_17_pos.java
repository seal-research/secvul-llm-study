

public class MyClass extends AbstractTestCase
{
    private void f279267() throws Throwable
    {
        for(int k = 0; k < 1; k++)
        {
            assert true; 
        }
    }
    public void f279269() throws Throwable
    {
        f279267();
    }
}