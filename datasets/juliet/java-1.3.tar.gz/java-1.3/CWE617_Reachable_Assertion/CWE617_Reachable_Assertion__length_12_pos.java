

public class MyClass extends AbstractTestCase
{
    private void f279337() throws Throwable
    {
        if (IO.staticReturnsTrueOrFalse())
        {
            assert "cwe617".length() > 0;
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279339() throws Throwable
    {
        f279337();
    }
}