

public class MyClass extends AbstractTestCase
{
    private void f279401() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279403() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE == 5)
        {
            assert true; 
        }
    }
    public void f279405() throws Throwable
    {
        f279401();
        f279403();
    }
}