

public class MyClass extends AbstractTestCase
{
    private void f279706() throws Throwable
    {
        for(int k = 0; k < 1; k++)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279708 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279708.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279708 = null;
            }
        }
    }
    public void f279711() throws Throwable
    {
        f279706();
    }
}