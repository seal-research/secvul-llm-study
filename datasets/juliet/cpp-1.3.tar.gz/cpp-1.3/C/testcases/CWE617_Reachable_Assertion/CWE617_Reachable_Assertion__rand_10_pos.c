
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249792()
{
    int data;
    data = -1;
    if(globalFalse)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f249793()
{
    int data;
    data = -1;
    if(globalTrue)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f249791()
{
    f249792();
    f249793();
}
