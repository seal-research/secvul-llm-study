
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticFive = 5;
void f106144()
{
    int data;
    data = -1;
    if(staticFive==5)
    {
        data = RAND32();
    }
    assert(data > ASSERT_VALUE);
}
