
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106492(int data)
{
    data = RAND32();
    return data;
}
void f106491()
{
    int data;
    data = -1;
    data = f106492(data);
    assert(data > ASSERT_VALUE);
}
