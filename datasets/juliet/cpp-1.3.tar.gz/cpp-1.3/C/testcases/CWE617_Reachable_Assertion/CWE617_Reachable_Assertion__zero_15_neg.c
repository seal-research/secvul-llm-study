
#include "std_testcase.h"
#include <assert.h>
void f106458()
{
    switch(6)
    {
    case 6:
        assert(0); 
        break;
    default:
        printLine("Benign, fixed string");
        break;
    }
}
