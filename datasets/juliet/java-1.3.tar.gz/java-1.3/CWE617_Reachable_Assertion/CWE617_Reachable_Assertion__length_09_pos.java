

public class MyClass extends AbstractTestCase
{
    private void f279281() throws Throwable
    {
        if (IO.STATIC_FINAL_FALSE)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279283() throws Throwable
    {
        if (IO.STATIC_FINAL_TRUE)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279285() throws Throwable
    {
        f279281();
        f279283();
    }
}