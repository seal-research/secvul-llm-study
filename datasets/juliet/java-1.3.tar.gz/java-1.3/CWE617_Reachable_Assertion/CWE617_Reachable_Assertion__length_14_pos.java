

public class MyClass extends AbstractTestCase
{
    private void f279408() throws Throwable
    {
        if (IO.staticFive != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279410() throws Throwable
    {
        if (IO.staticFive == 5)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279412() throws Throwable
    {
        f279408();
        f279410();
    }
}