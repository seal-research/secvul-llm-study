

public class MyClass extends AbstractTestCase
{
    private void f279443() throws Throwable
    {
        while(true)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                IO.writeLine("In finally block, cleaning up");
            }
            break;
        }
    }
    public void f279445() throws Throwable
    {
        f279443();
    }
}