

public class MyClass extends AbstractTestCase
{
    private static final int PRIVATE_STATIC_FINAL_FIVE = 5;
    public void f192703() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE == 5)
        {
            assert "".length() > 0;
        }
    }
}