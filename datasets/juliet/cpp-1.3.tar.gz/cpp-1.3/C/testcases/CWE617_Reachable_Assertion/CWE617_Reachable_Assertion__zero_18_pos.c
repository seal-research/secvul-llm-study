
#include "std_testcase.h"
#include <assert.h>
static void f249974()
{
    goto sink;
sink:
    assert(1); 
}
void f249973()
{
    f249974();
}
