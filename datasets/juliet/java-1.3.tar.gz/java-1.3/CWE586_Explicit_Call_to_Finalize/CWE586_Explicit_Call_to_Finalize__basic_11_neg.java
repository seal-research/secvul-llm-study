

public class MyClass extends AbstractTestCase
{
    public void f192929() throws Throwable
    {
        if (IO.staticReturnsTrue())
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192929Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192929Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192929Obj.finalize();
            }
        }
    }
}