

public class MyClass extends AbstractTestCase
{
    private void f279316() throws Throwable
    {
        if (5 != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279318() throws Throwable
    {
        if (5 == 5)
        {
            assert true; 
        }
    }
    public void f279320() throws Throwable
    {
        f279316();
        f279318();
    }
}