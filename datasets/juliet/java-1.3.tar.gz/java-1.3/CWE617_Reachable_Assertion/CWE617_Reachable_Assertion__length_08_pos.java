

public class MyClass extends AbstractTestCase
{
    private boolean privateReturnsTrue()
    {
        return true;
    }
    private boolean privateReturnsFalse()
    {
        return false;
    }
    private void f279341() throws Throwable
    {
        if (privateReturnsFalse())
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279343() throws Throwable
    {
        if (privateReturnsTrue())
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279345() throws Throwable
    {
        f279341();
        f279343();
    }
}