
#include "std_testcase.h"
#include <assert.h>
static const int STATIC_CONST_TRUE = 1; 
static const int STATIC_CONST_FALSE = 0; 
void f106128()
{
    if(STATIC_CONST_TRUE)
    {
        assert(0); 
    }
}
