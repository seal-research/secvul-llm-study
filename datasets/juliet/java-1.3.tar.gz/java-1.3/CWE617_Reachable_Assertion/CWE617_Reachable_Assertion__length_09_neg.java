

public class MyClass extends AbstractTestCase
{
    public void f192709() throws Throwable
    {
        if (IO.STATIC_FINAL_TRUE)
        {
            assert "".length() > 0;
        }
    }
}