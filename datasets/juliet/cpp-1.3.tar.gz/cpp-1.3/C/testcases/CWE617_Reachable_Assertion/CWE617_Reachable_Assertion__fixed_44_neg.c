
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f106167(int data)
{
    assert(data > ASSERT_VALUE);
}
void f106166()
{
    int data;
    void (*funcPtr) (int) = f106167;
    data = -1;
    data = ASSERT_VALUE-1;
    funcPtr(data);
}
