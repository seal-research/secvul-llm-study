

public class MyClass extends AbstractTestCase
{
    private static final boolean PRIVATE_STATIC_FINAL_TRUE = true;
    private static final boolean PRIVATE_STATIC_FINAL_FALSE = false;
    private void f279323() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FALSE)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279325() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_TRUE)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279327() throws Throwable
    {
        f279323();
        f279325();
    }
}