

public class MyClass extends AbstractTestCase
{
    public void f192775() throws Throwable
    {
        if (true)
        {
            assert "".length() > 0;
        }
    }
}