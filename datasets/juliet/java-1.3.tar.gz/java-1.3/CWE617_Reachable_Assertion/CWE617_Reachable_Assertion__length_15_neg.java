

public class MyClass extends AbstractTestCase
{
    public void f192751() throws Throwable
    {
        switch (7)
        {
        case 7:
            assert "".length() > 0;
            break;
        default:
            IO.writeLine("Benign, fixed string");
            break;
        }
    }
}