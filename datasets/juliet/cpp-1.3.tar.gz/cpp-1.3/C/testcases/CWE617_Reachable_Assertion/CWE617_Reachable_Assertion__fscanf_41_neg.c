
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106099Sink(int data)
{
    assert(data > ASSERT_VALUE);
}
void f106099()
{
    int data;
    data = -1;
    fscanf(stdin, "%d", &data);
    f106099Sink(data);
}
