

public class MyClass extends AbstractTestCase
{
    private int privateFive = 5;
    public void f192681() throws Throwable
    {
        if (privateFive == 5)
        {
            assert false; 
        }
    }
}