

public class MyClass extends AbstractTestCase
{
    public void f279278() throws Throwable
    {
        f2792781();
    }
    private void f2792781() throws Throwable
    {
        assert true; 
    }
}