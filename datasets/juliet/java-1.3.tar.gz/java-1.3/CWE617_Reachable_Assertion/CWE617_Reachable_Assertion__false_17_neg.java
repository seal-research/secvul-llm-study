

public class MyClass extends AbstractTestCase
{
    public void f192700() throws Throwable
    {
        for(int j = 0; j < 1; j++)
        {
            assert false; 
        }
    }
}