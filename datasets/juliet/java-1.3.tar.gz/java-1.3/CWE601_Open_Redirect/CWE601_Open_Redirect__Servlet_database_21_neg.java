

import javax.servlet.http.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f191992 = false;
    public void f191993(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f191992 = true;
        data = f191993_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f191993_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f191992)
        {
            data = ""; 
            {
                Connection connection = null;
                PreparedStatement preparedStatement = null;
                ResultSet resultSet = null;
                try
                {
                    connection = IO.getDBConnection();
                    preparedStatement = connection.prepareStatement("select name from users where id=0");
                    resultSet = preparedStatement.executeQuery();
                    data = resultSet.getString(1);
                }
                catch (SQLException exceptSql)
                {
                    IO.logger.log(Level.WARNING, "Error with SQL statement", exceptSql);
                }
                finally
                {
                    try
                    {
                        if (resultSet != null)
                        {
                            resultSet.close();
                        }
                    }
                    catch (SQLException exceptSql)
                    {
                        IO.logger.log(Level.WARNING, "Error closing ResultSet", exceptSql);
                    }
                    try
                    {
                        if (preparedStatement != null)
                        {
                            preparedStatement.close();
                        }
                    }
                    catch (SQLException exceptSql)
                    {
                        IO.logger.log(Level.WARNING, "Error closing PreparedStatement", exceptSql);
                    }
                    try
                    {
                        if (connection != null)
                        {
                            connection.close();
                        }
                    }
                    catch (SQLException exceptSql)
                    {
                        IO.logger.log(Level.WARNING, "Error closing Connection", exceptSql);
                    }
                }
            }
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f192000 = false;
    private boolean f192001 = false;
    private String f192002_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f192000)
        {
            data = null;
        }
        else
        {
            data = "foo";
        }
        return data;
    }
    private String f192006_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f192001)
        {
            data = "foo";
        }
        else
        {
            data = null;
        }
        return data;
    }
}