

import javax.servlet.http.*;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f277889 = false;
    private String f277890(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f277889)
        {
            data = request.getParameter("name");
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f277894 = false;
    private boolean f277895 = false;
    public void f277896(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        f277896G2B1(request, response);
        f277896G2B2(request, response);
    }
    private void f277896G2B1(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f277894 = false;
        data = f277896G2B1_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f277896G2B1_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f277894)
        {
            data = null;
        }
        else
        {
            data = "foo";
        }
        return data;
    }
    private void f277896G2B2(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f277895 = true;
        data = f277896G2B2_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f277896G2B2_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f277895)
        {
            data = "foo";
        }
        else
        {
            data = null;
        }
        return data;
    }
}