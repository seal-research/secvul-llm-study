
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
namespace Test12212
{
static void f249930()
{
    int data;
    int &dataRef = data;
    data = -1;
    data = ASSERT_VALUE+1;
    {
        int data = dataRef;
        assert(data > ASSERT_VALUE);
    }
}
void f249931()
{
    f249930();
}
} 
