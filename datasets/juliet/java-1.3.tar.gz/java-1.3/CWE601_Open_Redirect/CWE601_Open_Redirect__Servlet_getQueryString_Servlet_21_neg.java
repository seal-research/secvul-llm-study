

import javax.servlet.http.*;
import java.util.StringTokenizer;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f190786 = false;
    public void f190787(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f190786 = true;
        data = f190787_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f190787_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f190786)
        {
            data = ""; 
            {
                StringTokenizer tokenizer = new StringTokenizer(request.getQueryString(), "&");
                while (tokenizer.hasMoreTokens())
                {
                    String token = tokenizer.nextToken(); 
                    if(token.startsWith("id=")) 
                    {
                        data = token.substring(3); 
                        break; 
                    }
                }
            }
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f190794 = false;
    private boolean f190795 = false;
    private String f190796_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f190794)
        {
            data = null;
        }
        else
        {
            data = "foo";
        }
        return data;
    }
    private String f190800_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f190795)
        {
            data = "foo";
        }
        else
        {
            data = null;
        }
        return data;
    }
}