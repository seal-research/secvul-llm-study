

public class MyClass extends AbstractTestCase
{
    public void f192961() throws Throwable
    {
        while(true)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192961Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192961Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192961Obj.finalize();
            }
            break;
        }
    }
}