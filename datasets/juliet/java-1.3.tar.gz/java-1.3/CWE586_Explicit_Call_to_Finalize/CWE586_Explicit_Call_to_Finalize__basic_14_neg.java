

public class MyClass extends AbstractTestCase
{
    public void f192871() throws Throwable
    {
        if (IO.staticFive == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192871Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192871Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192871Obj.finalize();
            }
        }
    }
}