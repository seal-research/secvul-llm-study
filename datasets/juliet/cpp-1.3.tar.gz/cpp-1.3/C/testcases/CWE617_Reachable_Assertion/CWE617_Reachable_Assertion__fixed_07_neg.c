
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticFive = 5;
void f106245()
{
    int data;
    data = -1;
    if(staticFive==5)
    {
        data = ASSERT_VALUE-1;
    }
    assert(data > ASSERT_VALUE);
}
