
#include "std_testcase.h"
#include <assert.h>
void f106272()
{
    if(5==5)
    {
        assert(0); 
    }
}
