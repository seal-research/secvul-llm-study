

public class MyClass extends AbstractTestCase
{
    private static final int PRIVATE_STATIC_FINAL_FIVE = 5;
    public void f192943() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192943Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192943Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192943Obj.finalize();
            }
        }
    }
}