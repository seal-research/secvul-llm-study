
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f106267(int data)
{
    assert(data > ASSERT_VALUE);
}
void f106266()
{
    int data;
    void (*funcPtr) (int) = f106267;
    data = -1;
    data = RAND32();
    funcPtr(data);
}
