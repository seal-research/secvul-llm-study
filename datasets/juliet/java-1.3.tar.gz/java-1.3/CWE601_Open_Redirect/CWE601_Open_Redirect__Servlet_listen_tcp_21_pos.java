

import javax.servlet.http.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.logging.Level;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f277478 = false;
    private String f277479(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f277478)
        {
            data = ""; 
            {
                ServerSocket listener = null;
                Socket socket = null;
                BufferedReader readerBuffered = null;
                InputStreamReader readerInputStream = null;
                try
                {
                    listener = new ServerSocket(39543);
                    socket = listener.accept();
                    readerInputStream = new InputStreamReader(socket.getInputStream(), "UTF-8");
                    readerBuffered = new BufferedReader(readerInputStream);
                    data = readerBuffered.readLine();
                }
                catch (IOException exceptIO)
                {
                    IO.logger.log(Level.WARNING, "Error with stream reading", exceptIO);
                }
                finally
                {
                    try
                    {
                        if (readerBuffered != null)
                        {
                            readerBuffered.close();
                        }
                    }
                    catch (IOException exceptIO)
                    {
                        IO.logger.log(Level.WARNING, "Error closing BufferedReader", exceptIO);
                    }
                    try
                    {
                        if (readerInputStream != null)
                        {
                            readerInputStream.close();
                        }
                    }
                    catch (IOException exceptIO)
                    {
                        IO.logger.log(Level.WARNING, "Error closing InputStreamReader", exceptIO);
                    }
                    try
                    {
                        if (socket != null)
                        {
                            socket.close();
                        }
                    }
                    catch (IOException exceptIO)
                    {
                        IO.logger.log(Level.WARNING, "Error closing Socket", exceptIO);
                    }
                    try
                    {
                        if (listener != null)
                        {
                            listener.close();
                        }
                    }
                    catch (IOException exceptIO)
                    {
                        IO.logger.log(Level.WARNING, "Error closing ServerSocket", exceptIO);
                    }
                }
            }
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f277483 = false;
    private boolean f277484 = false;
    public void f277485(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        f277485G2B1(request, response);
        f277485G2B2(request, response);
    }
    private void f277485G2B1(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f277483 = false;
        data = f277485G2B1_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f277485G2B1_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f277483)
        {
            data = null;
        }
        else
        {
            data = "foo";
        }
        return data;
    }
    private void f277485G2B2(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f277484 = true;
        data = f277485G2B2_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f277485G2B2_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f277484)
        {
            data = "foo";
        }
        else
        {
            data = null;
        }
        return data;
    }
}