

public class MyClass extends AbstractTestCase
{
    public void f192806() throws Throwable
    {
        for(int j = 0; j < 1; j++)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
        }
    }
}