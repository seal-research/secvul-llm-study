

public class MyClass extends AbstractTestCase
{
    private boolean privateReturnsTrue()
    {
        return true;
    }
    private boolean privateReturnsFalse()
    {
        return false;
    }
    private void f279635() throws Throwable
    {
        if (privateReturnsFalse())
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279637 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279637.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279637 = null;
            }
        }
    }
    private void f279640() throws Throwable
    {
        if (privateReturnsTrue())
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279637 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279637.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279637 = null;
            }
        }
    }
    public void f279645() throws Throwable
    {
        f279635();
        f279640();
    }
}