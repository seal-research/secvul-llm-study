
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106061Data;
static int f106062G2BData;
static void f106066()
{
    int data = f106061Data;
    assert(data > ASSERT_VALUE);
}
void f106061()
{
    int data;
    data = -1;
    fscanf(stdin, "%d", &data);
    f106061Data = data;
    f106066();
}
