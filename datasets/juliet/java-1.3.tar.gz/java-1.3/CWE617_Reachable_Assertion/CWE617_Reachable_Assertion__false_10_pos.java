

public class MyClass extends AbstractTestCase
{
    private void f279217() throws Throwable
    {
        if (IO.staticFalse)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279219() throws Throwable
    {
        if (IO.staticTrue)
        {
            assert true; 
        }
    }
    public void f279221() throws Throwable
    {
        f279217();
        f279219();
    }
}