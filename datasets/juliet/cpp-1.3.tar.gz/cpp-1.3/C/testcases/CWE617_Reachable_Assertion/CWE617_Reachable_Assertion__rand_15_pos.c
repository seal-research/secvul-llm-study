
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f250034()
{
    int data;
    data = -1;
    switch(5)
    {
    case 6:
        printLine("Benign, fixed string");
        break;
    default:
        data = ASSERT_VALUE+1;
        break;
    }
    assert(data > ASSERT_VALUE);
}
static void f250035()
{
    int data;
    data = -1;
    switch(6)
    {
    case 6:
        data = ASSERT_VALUE+1;
        break;
    default:
        printLine("Benign, fixed string");
        break;
    }
    assert(data > ASSERT_VALUE);
}
void f250033()
{
    f250034();
    f250035();
}
