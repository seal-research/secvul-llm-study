

public class MyClass extends AbstractTestCase
{
    private static final boolean PRIVATE_STATIC_FINAL_TRUE = true;
    private static final boolean PRIVATE_STATIC_FINAL_FALSE = false;
    private void f279612() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FALSE)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279614 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279614.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279614 = null;
            }
        }
    }
    private void f279617() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_TRUE)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279614 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279614.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279614 = null;
            }
        }
    }
    public void f279622() throws Throwable
    {
        f279612();
        f279617();
    }
}