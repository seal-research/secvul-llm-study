

public class MyClass extends AbstractTestCase
{
    public void f192878() throws Throwable
    {
        if (IO.STATIC_FINAL_TRUE)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192878Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192878Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192878Obj.finalize();
            }
        }
    }
}