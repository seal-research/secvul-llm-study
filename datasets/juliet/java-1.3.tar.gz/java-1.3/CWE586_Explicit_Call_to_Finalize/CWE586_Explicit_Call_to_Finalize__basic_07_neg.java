

public class MyClass extends AbstractTestCase
{
    private int privateFive = 5;
    public void f192922() throws Throwable
    {
        if (privateFive == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192922Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192922Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192922Obj.finalize();
            }
        }
    }
}