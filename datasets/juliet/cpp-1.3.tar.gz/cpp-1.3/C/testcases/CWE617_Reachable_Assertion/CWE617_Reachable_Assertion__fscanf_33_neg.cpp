
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12216
{
void f106519()
{
    int data;
    int &dataRef = data;
    data = -1;
    fscanf(stdin, "%d", &data);
    {
        int data = dataRef;
        assert(data > ASSERT_VALUE);
    }
}
} 
