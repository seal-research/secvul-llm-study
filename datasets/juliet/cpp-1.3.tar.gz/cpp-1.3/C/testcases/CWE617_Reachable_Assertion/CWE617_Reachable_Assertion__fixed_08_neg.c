
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticReturnsTrue()
{
    return 1;
}
static int staticReturnsFalse()
{
    return 0;
}
void f106412()
{
    int data;
    data = -1;
    if(staticReturnsTrue())
    {
        data = ASSERT_VALUE-1;
    }
    assert(data > ASSERT_VALUE);
}
