
#include "std_testcase.h"
#include <assert.h>
static void f250254()
{
    switch(5)
    {
    case 6:
        printLine("Benign, fixed string");
        break;
    default:
        assert(1); 
        break;
    }
}
static void f250255()
{
    switch(6)
    {
    case 6:
        assert(1); 
        break;
    default:
        printLine("Benign, fixed string");
        break;
    }
}
void f250253()
{
    f250254();
    f250255();
}
