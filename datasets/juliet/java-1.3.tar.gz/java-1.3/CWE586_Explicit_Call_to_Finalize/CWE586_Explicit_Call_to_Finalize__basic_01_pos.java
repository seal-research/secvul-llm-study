

public class MyClass extends AbstractTestCase
{
    public void f279700() throws Throwable
    {
        f2797001();
    }
    private void f2797001() throws Throwable
    {
        CWE586_Explicit_Call_to_Finalize__basic_Helper f279700Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
        try
        {
            f279700Obj.sayHello();
        }
        catch (Exception exception)
        {
            IO.writeLine("An error occurred.");
        }
        finally
        {
            f279700Obj = null;
        }
    }
}