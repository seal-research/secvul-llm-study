

public class MyClass extends AbstractTestCase
{
    public void f192717() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE == 5)
        {
            assert "".length() > 0;
        }
    }
}