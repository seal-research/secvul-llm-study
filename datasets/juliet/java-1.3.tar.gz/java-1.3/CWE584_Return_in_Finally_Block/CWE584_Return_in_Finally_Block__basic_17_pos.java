

public class MyClass extends AbstractTestCase
{
    private void f279447() throws Throwable
    {
        for(int k = 0; k < 1; k++)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                IO.writeLine("In finally block, cleaning up");
            }
        }
    }
    public void f279449() throws Throwable
    {
        f279447();
    }
}