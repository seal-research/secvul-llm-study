

public class MyClass extends AbstractTestCase
{
    private static final int PRIVATE_STATIC_FINAL_FIVE = 5;
    public void f192663() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE == 5)
        {
            assert false; 
        }
    }
}