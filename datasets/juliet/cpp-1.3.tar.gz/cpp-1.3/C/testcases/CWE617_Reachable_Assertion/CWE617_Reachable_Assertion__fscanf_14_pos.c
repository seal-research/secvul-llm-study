
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f250346()
{
    int data;
    data = -1;
    if(false)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f250347()
{
    int data;
    data = -1;
    if(true)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250345()
{
    f250346();
    f250347();
}
