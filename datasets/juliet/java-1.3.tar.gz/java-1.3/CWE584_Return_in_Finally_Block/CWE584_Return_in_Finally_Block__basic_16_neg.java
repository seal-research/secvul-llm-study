

public class MyClass extends AbstractTestCase
{
    public void f192803() throws Throwable
    {
        while(true)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
            break;
        }
    }
}