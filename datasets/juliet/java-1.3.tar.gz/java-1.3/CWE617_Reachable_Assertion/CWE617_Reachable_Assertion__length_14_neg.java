

public class MyClass extends AbstractTestCase
{
    public void f192783() throws Throwable
    {
        if (IO.staticFive == 5)
        {
            assert "".length() > 0;
        }
    }
}