

public class MyClass extends AbstractTestCase
{
    private void f279224() throws Throwable
    {
        while(true)
        {
            assert "cwe617".length() > 0;
            break;
        }
    }
    public void f279226() throws Throwable
    {
        f279224();
    }
}