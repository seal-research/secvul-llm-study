
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106207()
{
    int i;
    int data;
    data = -1;
    for(i = 0; i < 1; i++)
    {
        data = ASSERT_VALUE-1;
    }
    assert(data > ASSERT_VALUE);
}
