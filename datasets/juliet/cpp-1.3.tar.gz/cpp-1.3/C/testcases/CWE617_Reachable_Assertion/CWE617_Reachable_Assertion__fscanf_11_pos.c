
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249708()
{
    int data;
    data = -1;
    if(globalReturnsFalse())
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f249709()
{
    int data;
    data = -1;
    if(globalReturnsTrue())
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f249707()
{
    f249708();
    f249709();
}
