
#include "std_testcase.h"
#include <assert.h>
static void f250148()
{
    if(0)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f250149()
{
    if(1)
    {
        assert(1); 
    }
}
void f250147()
{
    f250148();
    f250149();
}
