
#include "std_testcase.h"
#include <assert.h>
void f106231()
{
    int j;
    for(j = 0; j < 1; j++)
    {
        assert(0); 
    }
}
