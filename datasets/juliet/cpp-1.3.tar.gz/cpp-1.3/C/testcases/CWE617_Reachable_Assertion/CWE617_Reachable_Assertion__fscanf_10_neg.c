
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106509()
{
    int data;
    data = -1;
    if(globalTrue)
    {
        fscanf(stdin, "%d", &data);
    }
    assert(data > ASSERT_VALUE);
}
