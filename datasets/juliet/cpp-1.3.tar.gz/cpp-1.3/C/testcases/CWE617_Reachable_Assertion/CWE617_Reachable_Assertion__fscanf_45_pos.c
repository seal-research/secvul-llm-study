
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f249531Data;
static int f249532G2BData;
static void f249536()
{
    int data = f249532G2BData;
    assert(data > ASSERT_VALUE);
}
static void f249537()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    f249532G2BData = data;
    f249536();
}
void f249532()
{
    f249537();
}
