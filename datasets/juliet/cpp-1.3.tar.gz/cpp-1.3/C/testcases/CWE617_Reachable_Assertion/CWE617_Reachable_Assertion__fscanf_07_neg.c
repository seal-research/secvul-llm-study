
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticFive = 5;
void f106334()
{
    int data;
    data = -1;
    if(staticFive==5)
    {
        fscanf(stdin, "%d", &data);
    }
    assert(data > ASSERT_VALUE);
}
