
#include "std_testcase.h"
#include <assert.h>
static int staticReturnsTrue()
{
    return 1;
}
static int staticReturnsFalse()
{
    return 0;
}
static void f250121()
{
    if(staticReturnsFalse())
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f250122()
{
    if(staticReturnsTrue())
    {
        assert(1); 
    }
}
void f250120()
{
    f250121();
    f250122();
}
