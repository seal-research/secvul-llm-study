

public class MyClass extends AbstractTestCase
{
    public void f279451() throws Throwable
    {
        f2794511();
    }
    private void f2794511() throws Throwable
    {
        try
        {
            throw new IllegalArgumentException();
        }
        catch(IllegalArgumentException exceptIllegalArgument)
        {
            IO.writeLine("preventing incidental issues");
        }
        finally
        {
            IO.writeLine("In finally block, cleaning up");
        }
    }
}