
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static void f249952()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    {
        int dataCopy = data;
        int data = dataCopy;
        assert(data > ASSERT_VALUE);
    }
}
void f249951()
{
    f249952();
}
