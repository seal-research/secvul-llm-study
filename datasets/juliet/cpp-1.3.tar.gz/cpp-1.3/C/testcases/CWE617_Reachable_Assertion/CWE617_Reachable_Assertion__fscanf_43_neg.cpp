
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12215
{
static void f106348(int &data)
{
    fscanf(stdin, "%d", &data);
}
void f106349()
{
    int data;
    data = -1;
    f106348(data);
    assert(data > ASSERT_VALUE);
}
} 
