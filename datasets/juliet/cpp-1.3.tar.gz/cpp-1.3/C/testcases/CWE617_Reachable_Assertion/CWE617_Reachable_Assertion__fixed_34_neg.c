
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
typedef union
{
    int unionFirst;
    int unionSecond;
} CWE617_Reachable_Assertion__fixed_34_unionType;
void f106437()
{
    int data;
    CWE617_Reachable_Assertion__fixed_34_unionType myUnion;
    data = -1;
    data = ASSERT_VALUE-1;
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        assert(data > ASSERT_VALUE);
    }
}
