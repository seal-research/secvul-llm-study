
#include "std_testcase.h"
#include <assert.h>
void f106306()
{
    goto sink;
sink:
    assert(0); 
}
