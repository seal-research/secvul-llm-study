
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106479()
{
    int data;
    data = -1;
    switch(6)
    {
    case 6:
        data = ASSERT_VALUE-1;
        break;
    default:
        printLine("Benign, fixed string");
        break;
    }
    assert(data > ASSERT_VALUE);
}
