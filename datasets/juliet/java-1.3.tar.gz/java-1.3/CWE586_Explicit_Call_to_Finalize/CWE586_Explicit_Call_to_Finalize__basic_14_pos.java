

public class MyClass extends AbstractTestCase
{
    private void f279560() throws Throwable
    {
        if (IO.staticFive != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279562 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279562.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279562 = null;
            }
        }
    }
    private void f279565() throws Throwable
    {
        if (IO.staticFive == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279562 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279562.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279562 = null;
            }
        }
    }
    public void f279570() throws Throwable
    {
        f279560();
        f279565();
    }
}