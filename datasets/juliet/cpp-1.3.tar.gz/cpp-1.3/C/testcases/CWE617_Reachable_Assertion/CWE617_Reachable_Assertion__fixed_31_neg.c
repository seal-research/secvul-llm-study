
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106083()
{
    int data;
    data = -1;
    data = ASSERT_VALUE-1;
    {
        int dataCopy = data;
        int data = dataCopy;
        assert(data > ASSERT_VALUE);
    }
}
