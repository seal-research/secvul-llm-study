

public class MyClass extends AbstractTestCase
{
    public void f192795() throws Throwable
    {
        if (IO.staticReturnsTrue())
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
        }
    }
}