

public class MyClass extends AbstractTestCase
{
    public void f192846() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE == 5)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
        }
    }
}