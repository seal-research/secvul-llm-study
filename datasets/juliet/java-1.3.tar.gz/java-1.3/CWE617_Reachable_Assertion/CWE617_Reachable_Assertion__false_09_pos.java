

public class MyClass extends AbstractTestCase
{
    private void f279380() throws Throwable
    {
        if (IO.STATIC_FINAL_FALSE)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279382() throws Throwable
    {
        if (IO.STATIC_FINAL_TRUE)
        {
            assert true; 
        }
    }
    public void f279384() throws Throwable
    {
        f279380();
        f279382();
    }
}