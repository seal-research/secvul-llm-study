
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
typedef union
{
    int unionFirst;
    int unionSecond;
} CWE617_Reachable_Assertion__fgets_34_unionType;
static void f250072()
{
    int data;
    CWE617_Reachable_Assertion__fgets_34_unionType myUnion;
    data = -1;
    data = ASSERT_VALUE+1;
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        assert(data > ASSERT_VALUE);
    }
}
void f250071()
{
    f250072();
}
