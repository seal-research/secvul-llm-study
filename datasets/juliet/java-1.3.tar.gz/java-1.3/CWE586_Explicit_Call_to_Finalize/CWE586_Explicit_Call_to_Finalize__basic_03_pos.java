

public class MyClass extends AbstractTestCase
{
    private void f279534() throws Throwable
    {
        if (5 != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279536 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279536.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279536 = null;
            }
        }
    }
    private void f279539() throws Throwable
    {
        if (5 == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279536 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279536.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279536 = null;
            }
        }
    }
    public void f279544() throws Throwable
    {
        f279534();
        f279539();
    }
}