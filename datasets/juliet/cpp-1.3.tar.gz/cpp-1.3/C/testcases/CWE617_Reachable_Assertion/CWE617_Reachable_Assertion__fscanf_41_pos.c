
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f249589G2BSink(int data)
{
    assert(data > ASSERT_VALUE);
}
static void f249592()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    f249589G2BSink(data);
}
void f249589()
{
    f249592();
}
