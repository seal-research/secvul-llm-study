

public class MyClass extends AbstractTestCase
{
    private void f279228() throws Throwable
    {
        if (IO.staticReturnsFalse())
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279230() throws Throwable
    {
        if (IO.staticReturnsTrue())
        {
            assert true; 
        }
    }
    public void f279232() throws Throwable
    {
        f279228();
        f279230();
    }
}