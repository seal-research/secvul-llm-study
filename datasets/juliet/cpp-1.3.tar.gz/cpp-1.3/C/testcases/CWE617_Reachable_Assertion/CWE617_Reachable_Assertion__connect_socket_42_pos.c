
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#include <winsock2.h>
#include <windows.h>
#include <direct.h>
#pragma comment(lib, "ws2_32") 
#define CLOSE_SOCKET closesocket
#else 
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define CLOSE_SOCKET close
#define SOCKET int
#define TCP_PORT 27015
#define IP_ADDRESS "127.0.0.1"
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static int f249749(int data)
{
    data = ASSERT_VALUE+1;
    return data;
}
static void f249750()
{
    int data;
    data = -1;
    data = f249749(data);
    assert(data > ASSERT_VALUE);
}
void f249748()
{
    f249750();
}
