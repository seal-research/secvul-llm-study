

import javax.servlet.http.*;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f190731 = false;
    public void f190732(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f190731 = true;
        data = f190732_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f190732_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f190731)
        {
            data = ""; 
            {
                Cookie cookieSources[] = request.getCookies();
                if (cookieSources != null)
                {
                    data = cookieSources[0].getValue();
                }
            }
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f190739 = false;
    private boolean f190740 = false;
    private String f190741_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f190739)
        {
            data = null;
        }
        else
        {
            data = "foo";
        }
        return data;
    }
    private String f190745_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f190740)
        {
            data = "foo";
        }
        else
        {
            data = null;
        }
        return data;
    }
}