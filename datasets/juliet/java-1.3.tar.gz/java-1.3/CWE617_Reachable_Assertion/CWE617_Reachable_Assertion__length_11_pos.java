

public class MyClass extends AbstractTestCase
{
    private void f279249() throws Throwable
    {
        if (IO.staticReturnsFalse())
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279251() throws Throwable
    {
        if (IO.staticReturnsTrue())
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279253() throws Throwable
    {
        f279249();
        f279251();
    }
}