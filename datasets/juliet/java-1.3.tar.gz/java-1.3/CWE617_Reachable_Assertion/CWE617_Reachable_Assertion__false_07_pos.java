

public class MyClass extends AbstractTestCase
{
    private int privateFive = 5;
    private void f279235() throws Throwable
    {
        if (privateFive != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279237() throws Throwable
    {
        if (privateFive == 5)
        {
            assert true; 
        }
    }
    public void f279239() throws Throwable
    {
        f279235();
        f279237();
    }
}