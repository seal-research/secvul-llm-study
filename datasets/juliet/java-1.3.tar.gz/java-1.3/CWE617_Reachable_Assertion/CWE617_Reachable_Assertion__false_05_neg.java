

public class MyClass extends AbstractTestCase
{
    private boolean privateTrue = true;
    private boolean privateFalse = false;
    public void f192771() throws Throwable
    {
        if (privateTrue)
        {
            assert false; 
        }
    }
}