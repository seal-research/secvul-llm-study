

public class MyClass extends AbstractTestCase
{
    public void f192677() throws Throwable
    {
        if (IO.staticReturnsTrue())
        {
            assert false; 
        }
    }
}