
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249559()
{
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;
    data = -1;
    {
        int data = *dataPtr1;
        data = ASSERT_VALUE+1;
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        assert(data > ASSERT_VALUE);
    }
}
void f249558()
{
    f249559();
}
