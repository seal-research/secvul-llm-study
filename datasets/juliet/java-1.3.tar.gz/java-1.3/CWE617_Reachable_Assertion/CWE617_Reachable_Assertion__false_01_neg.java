

public class MyClass extends AbstractTestCase
{
    public void f192707() throws Throwable
    {
        assert false; 
    }
}