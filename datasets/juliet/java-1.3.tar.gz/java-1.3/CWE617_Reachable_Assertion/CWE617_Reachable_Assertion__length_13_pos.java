

public class MyClass extends AbstractTestCase
{
    private void f279295() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279297() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE == 5)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279299() throws Throwable
    {
        f279295();
        f279297();
    }
}