
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249721(int data)
{
    assert(data > ASSERT_VALUE);
}
static void f249722()
{
    int data;
    void (*funcPtr) (int) = f249721;
    data = -1;
    data = ASSERT_VALUE+1;
    funcPtr(data);
}
void f249720()
{
    f249722();
}
