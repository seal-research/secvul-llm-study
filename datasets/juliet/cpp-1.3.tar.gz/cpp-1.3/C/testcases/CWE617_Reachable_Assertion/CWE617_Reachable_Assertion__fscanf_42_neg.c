
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106228(int data)
{
    fscanf(stdin, "%d", &data);
    return data;
}
void f106227()
{
    int data;
    data = -1;
    data = f106228(data);
    assert(data > ASSERT_VALUE);
}
