

public class MyClass extends AbstractTestCase
{
    public void f192791() throws Throwable
    {
        if (IO.staticTrue)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
        }
    }
}