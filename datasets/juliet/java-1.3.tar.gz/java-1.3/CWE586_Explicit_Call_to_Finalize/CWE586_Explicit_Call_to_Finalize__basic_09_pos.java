

public class MyClass extends AbstractTestCase
{
    private void f279573() throws Throwable
    {
        if (IO.STATIC_FINAL_FALSE)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279575 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279575.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279575 = null;
            }
        }
    }
    private void f279578() throws Throwable
    {
        if (IO.STATIC_FINAL_TRUE)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279575 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279575.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279575 = null;
            }
        }
    }
    public void f279583() throws Throwable
    {
        f279573();
        f279578();
    }
}