
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12208
{
static void f249651(int &data)
{
    data = ASSERT_VALUE+1;
}
static void f249652()
{
    int data;
    data = -1;
    f249651(data);
    assert(data > ASSERT_VALUE);
}
void f249654()
{
    f249652();
}
} 
