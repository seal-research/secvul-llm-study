
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106057()
{
    int data;
    data = -1;
    fscanf(stdin, "%d", &data);
    assert(data > ASSERT_VALUE);
}
