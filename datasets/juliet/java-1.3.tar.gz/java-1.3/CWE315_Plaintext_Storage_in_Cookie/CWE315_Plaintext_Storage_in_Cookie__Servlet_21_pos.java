

import javax.servlet.http.*;
import java.security.MessageDigest;
import java.net.PasswordAuthentication;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f279837 = false;
    private boolean f279838 = false;
    private boolean f279839 = false;
    private boolean f279840 = false;
    public void f279841(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        f279841B2G1(request, response);
        f279841B2G2(request, response);
        f279841G2B(request, response);
    }
    private void f279841B2G1(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        PasswordAuthentication credentials = new PasswordAuthentication("user", "BP@ssw0rd".toCharArray());
        data = credentials.getUserName() + ":" + (new String(credentials.getPassword()));
        f279838 = false;
        f279841B2G1Sink(data , request, response);
    }
    private void f279841B2G1Sink(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        if (f279838)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            {
                String salt = "ThisIsMySalt";
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
                messageDigest.reset();
                byte[] hashedCredsAsBytes = messageDigest.digest((salt+data).getBytes("UTF-8"));
                data = IO.toHex(hashedCredsAsBytes);
            }
            response.addCookie(new Cookie("auth", data));
        }
    }
    private void f279841B2G2(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        PasswordAuthentication credentials = new PasswordAuthentication("user", "BP@ssw0rd".toCharArray());
        data = credentials.getUserName() + ":" + (new String(credentials.getPassword()));
        f279839 = true;
        f279841B2G2Sink(data , request, response);
    }
    private void f279841B2G2Sink(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        if (f279839)
        {
            {
                String salt = "ThisIsMySalt";
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
                messageDigest.reset();
                byte[] hashedCredsAsBytes = messageDigest.digest((salt+data).getBytes("UTF-8"));
                data = IO.toHex(hashedCredsAsBytes);
            }
            response.addCookie(new Cookie("auth", data));
        }
    }
    private void f279841G2B(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        PasswordAuthentication credentials = new PasswordAuthentication("user", "GP@ssw0rd".toCharArray());
        {
            String salt = "ThisIsMySalt";
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
            messageDigest.reset();
            String credentialsToHash = credentials.getUserName() + ":" + (new String(credentials.getPassword()));
            byte[] hashedCredsAsBytes = messageDigest.digest((salt+credentialsToHash).getBytes("UTF-8"));
            data = IO.toHex(hashedCredsAsBytes);
        }
        f279840 = true;
        f279841G2BSink(data , request, response);
    }
    private void f279841G2BSink(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        if (f279840)
        {
            response.addCookie(new Cookie("auth", data));
        }
    }
}