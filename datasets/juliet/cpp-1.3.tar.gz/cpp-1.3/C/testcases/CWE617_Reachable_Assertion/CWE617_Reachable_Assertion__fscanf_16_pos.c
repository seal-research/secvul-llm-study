
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249872()
{
    int data;
    data = -1;
    while(1)
    {
        data = ASSERT_VALUE+1;
        break;
    }
    assert(data > ASSERT_VALUE);
}
void f249871()
{
    f249872();
}
