

public class MyClass extends AbstractTestCase
{
    private static final boolean PRIVATE_STATIC_FINAL_TRUE = true;
    private static final boolean PRIVATE_STATIC_FINAL_FALSE = false;
    public void f192899() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_TRUE)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192899Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192899Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192899Obj.finalize();
            }
        }
    }
}