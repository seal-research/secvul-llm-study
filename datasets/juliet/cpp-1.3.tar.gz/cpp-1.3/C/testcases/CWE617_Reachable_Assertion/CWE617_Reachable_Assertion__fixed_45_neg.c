
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106523Data;
static int f106524G2BData;
static void f106528()
{
    int data = f106523Data;
    assert(data > ASSERT_VALUE);
}
void f106523()
{
    int data;
    data = -1;
    data = ASSERT_VALUE-1;
    f106523Data = data;
    f106528();
}
