
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
void f249994G2BSink(int data)
{
    assert(data > ASSERT_VALUE);
}
static void f249997()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    f249994G2BSink(data);
}
void f249994()
{
    f249997();
}
