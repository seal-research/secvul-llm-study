
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticTrue = 1; 
static int staticFalse = 0; 
static void f249606()
{
    int data;
    data = -1;
    if(staticFalse)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f249607()
{
    int data;
    data = -1;
    if(staticTrue)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f249605()
{
    f249606();
    f249607();
}
