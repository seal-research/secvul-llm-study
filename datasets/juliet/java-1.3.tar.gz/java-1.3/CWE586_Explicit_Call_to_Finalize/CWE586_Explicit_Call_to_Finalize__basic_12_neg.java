

public class MyClass extends AbstractTestCase
{
    public void f192906() throws Throwable
    {
        if (IO.staticReturnsTrueOrFalse())
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192906Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192906Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192906Obj.finalize();
            }
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192910 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192910.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192910 = null;
            }
        }
    }
}