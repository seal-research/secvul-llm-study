
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticTrue = 1; 
static int staticFalse = 0; 
void f106366()
{
    int data;
    data = -1;
    if(staticTrue)
    {
        data = RAND32();
    }
    assert(data > ASSERT_VALUE);
}
