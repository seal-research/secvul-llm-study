
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
typedef union
{
    int unionFirst;
    int unionSecond;
} CWE617_Reachable_Assertion__rand_34_unionType;
static void f249971()
{
    int data;
    CWE617_Reachable_Assertion__rand_34_unionType myUnion;
    data = -1;
    data = ASSERT_VALUE+1;
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        assert(data > ASSERT_VALUE);
    }
}
void f249970()
{
    f249971();
}
