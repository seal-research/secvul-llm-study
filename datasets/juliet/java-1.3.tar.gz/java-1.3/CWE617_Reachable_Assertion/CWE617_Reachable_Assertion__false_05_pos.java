

public class MyClass extends AbstractTestCase
{
    private boolean privateTrue = true;
    private boolean privateFalse = false;
    private void f279387() throws Throwable
    {
        if (privateFalse)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279389() throws Throwable
    {
        if (privateTrue)
        {
            assert true; 
        }
    }
    public void f279391() throws Throwable
    {
        f279387();
        f279389();
    }
}