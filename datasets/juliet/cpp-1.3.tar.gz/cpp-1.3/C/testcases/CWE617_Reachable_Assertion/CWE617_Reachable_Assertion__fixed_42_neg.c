
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106375(int data)
{
    data = ASSERT_VALUE-1;
    return data;
}
void f106374()
{
    int data;
    data = -1;
    data = f106375(data);
    assert(data > ASSERT_VALUE);
}
