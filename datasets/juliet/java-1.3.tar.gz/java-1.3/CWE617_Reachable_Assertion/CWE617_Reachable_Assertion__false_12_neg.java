

public class MyClass extends AbstractTestCase
{
    public void f192748() throws Throwable
    {
        if (IO.staticReturnsTrueOrFalse())
        {
            assert false; 
        }
        else
        {
            assert true; 
        }
    }
}