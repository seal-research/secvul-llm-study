

public class MyClass extends AbstractTestCase
{
    public void f192737() throws Throwable
    {
        switch (7)
        {
        case 7:
            assert false; 
            break;
        default:
            IO.writeLine("Benign, fixed string");
            break;
        }
    }
}