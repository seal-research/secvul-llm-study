
#include "std_testcase.h"
#include <assert.h>
void f106312()
{
    if(globalReturnsTrueOrFalse())
    {
        assert(0); 
    }
    else
    {
        assert(1); 
    }
}
