
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106055()
{
    int data;
    data = -1;
    if(GLOBAL_CONST_FIVE==5)
    {
        data = RAND32();
    }
    assert(data > ASSERT_VALUE);
}
