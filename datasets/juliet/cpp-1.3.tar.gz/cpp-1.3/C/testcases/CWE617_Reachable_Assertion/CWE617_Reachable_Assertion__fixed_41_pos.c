
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f250306G2BSink(int data)
{
    assert(data > ASSERT_VALUE);
}
static void f250309()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    f250306G2BSink(data);
}
void f250306()
{
    f250309();
}
