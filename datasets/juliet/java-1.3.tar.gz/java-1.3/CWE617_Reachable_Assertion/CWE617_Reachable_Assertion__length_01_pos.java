

public class MyClass extends AbstractTestCase
{
    public void f279203() throws Throwable
    {
        f2792031();
    }
    private void f2792031() throws Throwable
    {
        assert "cwe617".length() > 0;
    }
}