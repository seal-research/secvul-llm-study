

public class MyClass extends AbstractTestCase
{
    public void f192667() throws Throwable
    {
        for(int j = 0; j < 1; j++)
        {
            assert "".length() > 0;
        }
    }
}