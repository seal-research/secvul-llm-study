

public class MyClass extends AbstractTestCase
{
    private void f279366() throws Throwable
    {
        if (5 != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279368() throws Throwable
    {
        if (5 == 5)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279370() throws Throwable
    {
        f279366();
        f279368();
    }
}