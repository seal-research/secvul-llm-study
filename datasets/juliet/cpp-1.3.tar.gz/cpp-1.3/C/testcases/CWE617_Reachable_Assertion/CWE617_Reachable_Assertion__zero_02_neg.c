
#include "std_testcase.h"
#include <assert.h>
void f106404()
{
    if(1)
    {
        assert(0); 
    }
}
