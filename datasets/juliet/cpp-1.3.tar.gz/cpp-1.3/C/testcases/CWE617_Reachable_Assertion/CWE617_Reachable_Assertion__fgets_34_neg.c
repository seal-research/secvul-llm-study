
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
typedef union
{
    int unionFirst;
    int unionSecond;
} CWE617_Reachable_Assertion__fgets_34_unionType;
void f106360()
{
    int data;
    CWE617_Reachable_Assertion__fgets_34_unionType myUnion;
    data = -1;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            data = atoi(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        assert(data > ASSERT_VALUE);
    }
}
