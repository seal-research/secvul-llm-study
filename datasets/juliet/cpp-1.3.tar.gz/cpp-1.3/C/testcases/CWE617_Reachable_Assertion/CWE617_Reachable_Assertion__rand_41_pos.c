
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f250102G2BSink(int data)
{
    assert(data > ASSERT_VALUE);
}
static void f250105()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    f250102G2BSink(data);
}
void f250102()
{
    f250105();
}
