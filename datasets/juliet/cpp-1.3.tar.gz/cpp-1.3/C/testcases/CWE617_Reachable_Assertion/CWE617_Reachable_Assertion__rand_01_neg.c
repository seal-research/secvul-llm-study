
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106406()
{
    int data;
    data = -1;
    data = RAND32();
    assert(data > ASSERT_VALUE);
}
