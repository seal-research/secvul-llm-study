

public class MyClass extends AbstractTestCase
{
    private void f279260() throws Throwable
    {
        if (IO.staticFalse)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279262() throws Throwable
    {
        if (IO.staticTrue)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279264() throws Throwable
    {
        f279260();
        f279262();
    }
}