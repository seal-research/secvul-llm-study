
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106336()
{
    int data;
    data = -1;
    switch(6)
    {
    case 6:
        data = RAND32();
        break;
    default:
        printLine("Benign, fixed string");
        break;
    }
    assert(data > ASSERT_VALUE);
}
