
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f250008()
{
    int data;
    data = -1;
    if(GLOBAL_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f250009()
{
    int data;
    data = -1;
    if(GLOBAL_CONST_TRUE)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250007()
{
    f250008();
    f250009();
}
