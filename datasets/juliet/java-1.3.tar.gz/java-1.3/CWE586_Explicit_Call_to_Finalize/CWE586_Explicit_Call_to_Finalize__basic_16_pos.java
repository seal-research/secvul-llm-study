

public class MyClass extends AbstractTestCase
{
    private void f279713() throws Throwable
    {
        while(true)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279715 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279715.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279715 = null;
            }
            break;
        }
    }
    public void f279718() throws Throwable
    {
        f279713();
    }
}