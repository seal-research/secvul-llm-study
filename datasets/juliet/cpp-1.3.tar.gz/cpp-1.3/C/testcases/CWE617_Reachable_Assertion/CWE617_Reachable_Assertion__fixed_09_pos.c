
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249942()
{
    int data;
    data = -1;
    if(GLOBAL_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f249943()
{
    int data;
    data = -1;
    if(GLOBAL_CONST_TRUE)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f249941()
{
    f249942();
    f249943();
}
