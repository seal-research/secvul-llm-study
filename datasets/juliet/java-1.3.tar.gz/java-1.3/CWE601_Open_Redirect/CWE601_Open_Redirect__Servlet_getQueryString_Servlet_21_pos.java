

import javax.servlet.http.*;
import java.util.StringTokenizer;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f276854 = false;
    private String f276855(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f276854)
        {
            data = ""; 
            {
                StringTokenizer tokenizer = new StringTokenizer(request.getQueryString(), "&");
                while (tokenizer.hasMoreTokens())
                {
                    String token = tokenizer.nextToken(); 
                    if(token.startsWith("id=")) 
                    {
                        data = token.substring(3); 
                        break; 
                    }
                }
            }
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f276859 = false;
    private boolean f276860 = false;
    public void f276861(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        f276861G2B1(request, response);
        f276861G2B2(request, response);
    }
    private void f276861G2B1(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f276859 = false;
        data = f276861G2B1_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f276861G2B1_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f276859)
        {
            data = null;
        }
        else
        {
            data = "foo";
        }
        return data;
    }
    private void f276861G2B2(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f276860 = true;
        data = f276861G2B2_source(request, response);
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private String f276861G2B2_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f276860)
        {
            data = "foo";
        }
        else
        {
            data = null;
        }
        return data;
    }
}