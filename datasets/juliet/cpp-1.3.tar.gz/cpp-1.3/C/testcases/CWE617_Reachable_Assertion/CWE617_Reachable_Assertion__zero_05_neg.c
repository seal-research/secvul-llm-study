
#include "std_testcase.h"
#include <assert.h>
static int staticTrue = 1; 
static int staticFalse = 0; 
void f106487()
{
    if(staticTrue)
    {
        assert(0); 
    }
}
