

public class MyClass extends AbstractTestCase
{
    private void f279330() throws Throwable
    {
        switch (8)
        {
        case 7:
            IO.writeLine("Benign, fixed string");
            break;
        default:
            assert true; 
            break;
        }
    }
    private void f279332() throws Throwable
    {
        switch (7)
        {
        case 7:
            assert true; 
            break;
        default:
            IO.writeLine("Benign, fixed string");
            break;
        }
    }
    public void f279334() throws Throwable
    {
        f279330();
        f279332();
    }
}