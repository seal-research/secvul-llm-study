
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static void f249713()
{
    int h;
    int data;
    data = -1;
    for(h = 0; h < 1; h++)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f249712()
{
    f249713();
}
