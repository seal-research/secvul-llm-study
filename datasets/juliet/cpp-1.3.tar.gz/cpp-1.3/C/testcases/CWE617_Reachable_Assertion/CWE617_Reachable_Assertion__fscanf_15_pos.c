
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249670()
{
    int data;
    data = -1;
    switch(5)
    {
    case 6:
        printLine("Benign, fixed string");
        break;
    default:
        data = ASSERT_VALUE+1;
        break;
    }
    assert(data > ASSERT_VALUE);
}
static void f249671()
{
    int data;
    data = -1;
    switch(6)
    {
    case 6:
        data = ASSERT_VALUE+1;
        break;
    default:
        printLine("Benign, fixed string");
        break;
    }
    assert(data > ASSERT_VALUE);
}
void f249669()
{
    f249670();
    f249671();
}
