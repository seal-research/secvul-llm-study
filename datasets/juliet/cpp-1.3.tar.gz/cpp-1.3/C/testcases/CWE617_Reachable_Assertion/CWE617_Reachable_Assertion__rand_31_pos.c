
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249831()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    {
        int dataCopy = data;
        int data = dataCopy;
        assert(data > ASSERT_VALUE);
    }
}
void f249830()
{
    f249831();
}
