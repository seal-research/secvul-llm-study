
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106394Data;
static int f106395G2BData;
static void f106399()
{
    int data = f106394Data;
    assert(data > ASSERT_VALUE);
}
void f106394()
{
    int data;
    data = -1;
    data = RAND32();
    f106394Data = data;
    f106399();
}
