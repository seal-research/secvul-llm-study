

public class MyClass extends AbstractTestCase
{
    private boolean privateReturnsTrue()
    {
        return true;
    }
    private boolean privateReturnsFalse()
    {
        return false;
    }
    private void f279373() throws Throwable
    {
        if (privateReturnsFalse())
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279375() throws Throwable
    {
        if (privateReturnsTrue())
        {
            assert true; 
        }
    }
    public void f279377() throws Throwable
    {
        f279373();
        f279375();
    }
}