

public class MyClass extends AbstractTestCase
{
    private static final boolean PRIVATE_STATIC_FINAL_TRUE = true;
    private static final boolean PRIVATE_STATIC_FINAL_FALSE = false;
    private void f279359() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FALSE)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279361() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_TRUE)
        {
            assert true; 
        }
    }
    public void f279363() throws Throwable
    {
        f279359();
        f279361();
    }
}