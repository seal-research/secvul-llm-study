

public class MyClass extends AbstractTestCase
{
    private void f279547() throws Throwable
    {
        if (false)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279549 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279549.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279549 = null;
            }
        }
    }
    private void f279552() throws Throwable
    {
        if (true)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279549 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279549.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279549 = null;
            }
        }
    }
    public void f279557() throws Throwable
    {
        f279547();
        f279552();
    }
}