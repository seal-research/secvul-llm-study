
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12210
{
static void f249758()
{
    int data;
    int &dataRef = data;
    data = -1;
    data = ASSERT_VALUE+1;
    {
        int data = dataRef;
        assert(data > ASSERT_VALUE);
    }
}
void f249759()
{
    f249758();
}
} 
