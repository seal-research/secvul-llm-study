

public class MyClass extends AbstractTestCase
{
    public void f192838() throws Throwable
    {
        if (IO.STATIC_FINAL_TRUE)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
        }
    }
}