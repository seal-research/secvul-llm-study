

public class MyClass extends AbstractTestCase
{
    public void f192713() throws Throwable
    {
        if (IO.staticFive == 5)
        {
            assert false; 
        }
    }
}