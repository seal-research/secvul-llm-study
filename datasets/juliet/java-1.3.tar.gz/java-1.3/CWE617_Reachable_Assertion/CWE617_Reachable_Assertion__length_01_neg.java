

public class MyClass extends AbstractTestCase
{
    public void f192661() throws Throwable
    {
        assert "".length() > 0;
    }
}