
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f250080()
{
    int h;
    int data;
    data = -1;
    for(h = 0; h < 1; h++)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250079()
{
    f250080();
}
