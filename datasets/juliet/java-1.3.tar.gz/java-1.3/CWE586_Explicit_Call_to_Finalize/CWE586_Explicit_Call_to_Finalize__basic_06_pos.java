

public class MyClass extends AbstractTestCase
{
    private static final int PRIVATE_STATIC_FINAL_FIVE = 5;
    private void f279687() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279689 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279689.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279689 = null;
            }
        }
    }
    private void f279692() throws Throwable
    {
        if (PRIVATE_STATIC_FINAL_FIVE == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279689 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279689.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279689 = null;
            }
        }
    }
    public void f279697() throws Throwable
    {
        f279687();
        f279692();
    }
}