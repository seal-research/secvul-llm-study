
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f250013()
{
    int data;
    data = -1;
    goto source;
source:
    data = ASSERT_VALUE+1;
    assert(data > ASSERT_VALUE);
}
void f250012()
{
    f250013();
}
