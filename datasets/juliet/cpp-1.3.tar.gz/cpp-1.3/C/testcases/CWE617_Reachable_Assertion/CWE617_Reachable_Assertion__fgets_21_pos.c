
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static int f249762 = 0;
static int f249763 = 0;
static int f249764(int data)
{
    if(f249762)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    return data;
}
static void f249766()
{
    int data;
    data = -1;
    f249762 = 0; 
    data = f249764(data);
    assert(data > ASSERT_VALUE);
}
static int f249769(int data)
{
    if(f249763)
    {
        data = ASSERT_VALUE+1;
    }
    return data;
}
static void f249771()
{
    int data;
    data = -1;
    f249763 = 1; 
    data = f249769(data);
    assert(data > ASSERT_VALUE);
}
void f249761()
{
    f249766();
    f249771();
}
