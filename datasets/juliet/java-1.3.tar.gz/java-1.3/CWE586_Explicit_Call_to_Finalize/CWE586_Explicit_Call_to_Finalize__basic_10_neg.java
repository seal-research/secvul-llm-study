

public class MyClass extends AbstractTestCase
{
    public void f192936() throws Throwable
    {
        if (IO.staticTrue)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192936Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192936Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192936Obj.finalize();
            }
        }
    }
}