
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106475()
{
    int data;
    data = -1;
    while(1)
    {
        data = RAND32();
        break;
    }
    assert(data > ASSERT_VALUE);
}
