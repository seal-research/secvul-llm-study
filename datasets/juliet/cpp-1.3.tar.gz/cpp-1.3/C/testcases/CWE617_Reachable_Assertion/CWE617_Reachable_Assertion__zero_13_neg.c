
#include "std_testcase.h"
#include <assert.h>
void f106178()
{
    if(GLOBAL_CONST_FIVE==5)
    {
        assert(0); 
    }
}
