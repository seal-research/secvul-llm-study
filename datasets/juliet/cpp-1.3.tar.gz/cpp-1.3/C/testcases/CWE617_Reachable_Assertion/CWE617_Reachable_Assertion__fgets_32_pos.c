
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static void f249695()
{
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;
    data = -1;
    {
        int data = *dataPtr1;
        data = ASSERT_VALUE+1;
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        assert(data > ASSERT_VALUE);
    }
}
void f249694()
{
    f249695();
}
