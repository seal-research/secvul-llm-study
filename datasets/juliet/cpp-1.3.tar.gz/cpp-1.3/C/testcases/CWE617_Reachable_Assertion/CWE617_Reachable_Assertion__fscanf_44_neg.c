
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f106453(int data)
{
    assert(data > ASSERT_VALUE);
}
void f106452()
{
    int data;
    void (*funcPtr) (int) = f106453;
    data = -1;
    fscanf(stdin, "%d", &data);
    funcPtr(data);
}
