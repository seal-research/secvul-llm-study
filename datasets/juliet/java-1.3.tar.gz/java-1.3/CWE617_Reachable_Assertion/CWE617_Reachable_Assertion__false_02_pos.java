

public class MyClass extends AbstractTestCase
{
    private void f279302() throws Throwable
    {
        if (false)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert true; 
        }
    }
    private void f279304() throws Throwable
    {
        if (true)
        {
            assert true; 
        }
    }
    public void f279306() throws Throwable
    {
        f279302();
        f279304();
    }
}