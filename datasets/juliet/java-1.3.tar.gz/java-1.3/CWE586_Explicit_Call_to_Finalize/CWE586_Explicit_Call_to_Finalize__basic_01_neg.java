

public class MyClass extends AbstractTestCase
{
    public void f192950() throws Throwable
    {
        CWE586_Explicit_Call_to_Finalize__basic_Helper f192950Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
        try
        {
            f192950Obj.sayHello();
        }
        catch (Exception exception)
        {
            IO.writeLine("An error occurred.");
        }
        finally
        {
            f192950Obj.finalize();
        }
    }
}