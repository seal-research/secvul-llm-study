

public class MyClass extends AbstractTestCase
{
    public void f192850() throws Throwable
    {
        switch (7)
        {
        case 7:
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192850Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192850Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192850Obj.finalize();
            }
            break;
        default:
            IO.writeLine("Benign, fixed string");
            break;
        }
    }
}