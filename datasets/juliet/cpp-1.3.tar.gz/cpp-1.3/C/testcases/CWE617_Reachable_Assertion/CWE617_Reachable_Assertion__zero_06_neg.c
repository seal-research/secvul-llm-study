
#include "std_testcase.h"
#include <assert.h>
static const int STATIC_CONST_FIVE = 5;
void f106384()
{
    if(STATIC_CONST_FIVE==5)
    {
        assert(0); 
    }
}
