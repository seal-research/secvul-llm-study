
#include "std_testcase.h"
#include <assert.h>
static void f250234()
{
    if(globalReturnsFalse())
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f250235()
{
    if(globalReturnsTrue())
    {
        assert(1); 
    }
}
void f250233()
{
    f250234();
    f250235();
}
