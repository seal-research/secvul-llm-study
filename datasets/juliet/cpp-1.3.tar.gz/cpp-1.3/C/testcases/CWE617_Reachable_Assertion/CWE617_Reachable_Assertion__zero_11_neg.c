
#include "std_testcase.h"
#include <assert.h>
void f106448()
{
    if(globalReturnsTrue())
    {
        assert(0); 
    }
}
