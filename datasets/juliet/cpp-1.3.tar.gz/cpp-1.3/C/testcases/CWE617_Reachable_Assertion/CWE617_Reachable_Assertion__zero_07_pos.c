
#include "std_testcase.h"
#include <assert.h>
static int staticFive = 5;
static void f249898()
{
    if(staticFive!=5)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f249899()
{
    if(staticFive==5)
    {
        assert(1); 
    }
}
void f249897()
{
    f249898();
    f249899();
}
