

public class MyClass extends AbstractTestCase
{
    public void f192741() throws Throwable
    {
        if (IO.staticReturnsTrueOrFalse())
        {
            assert "".length() > 0;
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
}