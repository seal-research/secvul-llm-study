

public class MyClass extends AbstractTestCase
{
    public void f192767() throws Throwable
    {
        if (IO.STATIC_FINAL_TRUE)
        {
            assert false; 
        }
    }
}