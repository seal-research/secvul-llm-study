
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int staticTrue = 1; 
static int staticFalse = 0; 
static void f250083()
{
    int data;
    data = -1;
    if(staticFalse)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f250084()
{
    int data;
    data = -1;
    if(staticTrue)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250082()
{
    f250083();
    f250084();
}
