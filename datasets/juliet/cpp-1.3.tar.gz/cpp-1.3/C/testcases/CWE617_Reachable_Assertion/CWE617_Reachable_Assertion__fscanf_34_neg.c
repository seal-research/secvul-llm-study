
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
typedef union
{
    int unionFirst;
    int unionSecond;
} CWE617_Reachable_Assertion__fscanf_34_unionType;
void f106174()
{
    int data;
    CWE617_Reachable_Assertion__fscanf_34_unionType myUnion;
    data = -1;
    fscanf(stdin, "%d", &data);
    myUnion.unionFirst = data;
    {
        int data = myUnion.unionSecond;
        assert(data > ASSERT_VALUE);
    }
}
