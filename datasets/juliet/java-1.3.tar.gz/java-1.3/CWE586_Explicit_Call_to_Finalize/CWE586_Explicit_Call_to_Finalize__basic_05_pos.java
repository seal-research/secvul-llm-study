

public class MyClass extends AbstractTestCase
{
    private boolean privateTrue = true;
    private boolean privateFalse = false;
    private void f279599() throws Throwable
    {
        if (privateFalse)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279601 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279601.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279601 = null;
            }
        }
    }
    private void f279604() throws Throwable
    {
        if (privateTrue)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279601 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279601.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279601 = null;
            }
        }
    }
    public void f279609() throws Throwable
    {
        f279599();
        f279604();
    }
}