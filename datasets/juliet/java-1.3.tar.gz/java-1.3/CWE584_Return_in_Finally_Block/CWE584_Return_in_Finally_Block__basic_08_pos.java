

public class MyClass extends AbstractTestCase
{
    private boolean privateReturnsTrue()
    {
        return true;
    }
    private boolean privateReturnsFalse()
    {
        return false;
    }
    private void f279493() throws Throwable
    {
        if (privateReturnsFalse())
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                IO.writeLine("In finally block, cleaning up");
            }
        }
    }
    private void f279495() throws Throwable
    {
        if (privateReturnsTrue())
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                IO.writeLine("In finally block, cleaning up");
            }
        }
    }
    public void f279497() throws Throwable
    {
        f279493();
        f279495();
    }
}