

public class MyClass extends AbstractTestCase
{
    private int privateFive = 5;
    private void f279242() throws Throwable
    {
        if (privateFive != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279244() throws Throwable
    {
        if (privateFive == 5)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279246() throws Throwable
    {
        f279242();
        f279244();
    }
}