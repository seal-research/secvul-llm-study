
#include "std_testcase.h"
#include <assert.h>
void f106358()
{
    while(1)
    {
        assert(0); 
        break;
    }
}
