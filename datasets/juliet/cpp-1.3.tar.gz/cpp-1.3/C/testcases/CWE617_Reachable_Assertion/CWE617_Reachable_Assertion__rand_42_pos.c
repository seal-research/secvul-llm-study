
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f250320(int data)
{
    data = ASSERT_VALUE+1;
    return data;
}
static void f250321()
{
    int data;
    data = -1;
    data = f250320(data);
    assert(data > ASSERT_VALUE);
}
void f250319()
{
    f250321();
}
