
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106115()
{
    int i;
    int data;
    data = -1;
    for(i = 0; i < 1; i++)
    {
        data = RAND32();
    }
    assert(data > ASSERT_VALUE);
}
