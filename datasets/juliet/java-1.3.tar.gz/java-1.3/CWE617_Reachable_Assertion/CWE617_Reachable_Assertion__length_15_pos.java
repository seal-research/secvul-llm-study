

public class MyClass extends AbstractTestCase
{
    private void f279352() throws Throwable
    {
        switch (8)
        {
        case 7:
            IO.writeLine("Benign, fixed string");
            break;
        default:
            assert "cwe617".length() > 0;
            break;
        }
    }
    private void f279354() throws Throwable
    {
        switch (7)
        {
        case 7:
            assert "cwe617".length() > 0;
            break;
        default:
            IO.writeLine("Benign, fixed string");
            break;
        }
    }
    public void f279356() throws Throwable
    {
        f279352();
        f279354();
    }
}