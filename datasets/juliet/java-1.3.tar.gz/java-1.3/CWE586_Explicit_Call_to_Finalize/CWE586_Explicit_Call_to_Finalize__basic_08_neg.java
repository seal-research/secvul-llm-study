

public class MyClass extends AbstractTestCase
{
    private boolean privateReturnsTrue()
    {
        return true;
    }
    private boolean privateReturnsFalse()
    {
        return false;
    }
    public void f192915() throws Throwable
    {
        if (privateReturnsTrue())
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192915Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192915Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192915Obj.finalize();
            }
        }
    }
}