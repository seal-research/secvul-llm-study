
#include "std_testcase.h"
#include <assert.h>
static int staticReturnsTrue()
{
    return 1;
}
static int staticReturnsFalse()
{
    return 0;
}
void f106388()
{
    if(staticReturnsTrue())
    {
        assert(0); 
    }
}
