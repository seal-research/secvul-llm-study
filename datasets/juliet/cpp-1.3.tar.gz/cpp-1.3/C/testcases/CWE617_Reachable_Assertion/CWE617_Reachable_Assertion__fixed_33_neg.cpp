
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12210
{
void f106188()
{
    int data;
    int &dataRef = data;
    data = -1;
    data = ASSERT_VALUE-1;
    {
        int data = dataRef;
        assert(data > ASSERT_VALUE);
    }
}
} 
