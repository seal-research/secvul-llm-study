
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106346()
{
    int data;
    data = -1;
    while(1)
    {
        data = ASSERT_VALUE-1;
        break;
    }
    assert(data > ASSERT_VALUE);
}
