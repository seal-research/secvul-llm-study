

public class MyClass extends AbstractTestCase
{
    private boolean privateReturnsTrue()
    {
        return true;
    }
    private boolean privateReturnsFalse()
    {
        return false;
    }
    public void f192744() throws Throwable
    {
        if (privateReturnsTrue())
        {
            assert "".length() > 0;
        }
    }
}