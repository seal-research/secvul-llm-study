
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static int f250189(int data)
{
    data = ASSERT_VALUE+1;
    return data;
}
static void f250190()
{
    int data;
    data = -1;
    data = f250189(data);
    assert(data > ASSERT_VALUE);
}
void f250188()
{
    f250190();
}
