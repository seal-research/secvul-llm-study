

public class MyClass extends AbstractTestCase
{
    private boolean privateTrue = true;
    private boolean privateFalse = false;
    private void f279309() throws Throwable
    {
        if (privateFalse)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279311() throws Throwable
    {
        if (privateTrue)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279313() throws Throwable
    {
        f279309();
        f279311();
    }
}