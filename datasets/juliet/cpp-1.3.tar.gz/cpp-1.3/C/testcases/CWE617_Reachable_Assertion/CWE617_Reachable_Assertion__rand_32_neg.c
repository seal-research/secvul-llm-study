
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106079()
{
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;
    data = -1;
    {
        int data = *dataPtr1;
        data = RAND32();
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        assert(data > ASSERT_VALUE);
    }
}
