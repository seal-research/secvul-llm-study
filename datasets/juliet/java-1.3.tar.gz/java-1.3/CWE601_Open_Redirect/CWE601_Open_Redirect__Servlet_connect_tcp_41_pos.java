

import javax.servlet.http.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.net.URI;
import java.net.URISyntaxException;
public class MyClass extends AbstractTestCaseServlet
{
    public void f278311(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        f278311G2B(request, response);
    }
    private void f278311G2BSink(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        if (data != null)
        {
            URI uri;
            try
            {
                uri = new URI(data);
            }
            catch (URISyntaxException exceptURISyntax)
            {
                response.getWriter().write("Invalid redirect URL");
                return;
            }
            response.sendRedirect(data);
            return;
        }
    }
    private void f278311G2B(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        data = "foo";
        f278311G2BSink(data , request, response );
    }
}