

import javax.servlet.http.*;
import java.security.MessageDigest;
import java.net.PasswordAuthentication;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f193047 = false;
    public void f193048(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        PasswordAuthentication credentials = new PasswordAuthentication("user", "BP@ssw0rd".toCharArray());
        data = credentials.getUserName() + ":" + (new String(credentials.getPassword()));
        f193047 = true;
        f193048Sink(data , request, response);
    }
    private void f193048Sink(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        if (f193047)
        {
            response.addCookie(new Cookie("auth", data));
        }
    }
    private boolean f193053 = false;
    private boolean f193054 = false;
    private boolean f193055 = false;
}