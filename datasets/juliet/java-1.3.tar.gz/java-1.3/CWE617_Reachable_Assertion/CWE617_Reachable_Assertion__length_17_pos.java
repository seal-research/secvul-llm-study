

public class MyClass extends AbstractTestCase
{
    private void f279213() throws Throwable
    {
        for(int k = 0; k < 1; k++)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279215() throws Throwable
    {
        f279213();
    }
}