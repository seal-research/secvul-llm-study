
#include "std_testcase.h"
#include <assert.h>
static void f250069()
{
    while(1)
    {
        assert(1); 
        break;
    }
}
void f250068()
{
    f250069();
}
