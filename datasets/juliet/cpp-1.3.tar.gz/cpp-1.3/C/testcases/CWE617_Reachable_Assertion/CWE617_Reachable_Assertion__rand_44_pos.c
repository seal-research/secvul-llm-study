
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f249906(int data)
{
    assert(data > ASSERT_VALUE);
}
static void f249907()
{
    int data;
    void (*funcPtr) (int) = f249906;
    data = -1;
    data = ASSERT_VALUE+1;
    funcPtr(data);
}
void f249905()
{
    f249907();
}
