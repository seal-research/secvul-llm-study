
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106254 = 0;
static int f106255(int data)
{
    if(f106254)
    {
        data = RAND32();
    }
    return data;
}
void f106253()
{
    int data;
    data = -1;
    f106254 = 1; 
    data = f106255(data);
    assert(data > ASSERT_VALUE);
}
