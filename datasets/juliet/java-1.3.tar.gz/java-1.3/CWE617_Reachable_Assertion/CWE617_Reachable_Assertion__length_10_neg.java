

public class MyClass extends AbstractTestCase
{
    public void f192696() throws Throwable
    {
        if (IO.staticTrue)
        {
            assert "".length() > 0;
        }
    }
}