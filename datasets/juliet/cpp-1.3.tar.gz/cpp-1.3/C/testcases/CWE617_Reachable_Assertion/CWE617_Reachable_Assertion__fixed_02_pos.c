
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f250161()
{
    int data;
    data = -1;
    if(0)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f250162()
{
    int data;
    data = -1;
    if(1)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250160()
{
    f250161();
    f250162();
}
