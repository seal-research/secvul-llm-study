

public class MyClass extends AbstractTestCase
{
    public void f192670() throws Throwable
    {
        if (IO.staticTrue)
        {
            assert false; 
        }
    }
}