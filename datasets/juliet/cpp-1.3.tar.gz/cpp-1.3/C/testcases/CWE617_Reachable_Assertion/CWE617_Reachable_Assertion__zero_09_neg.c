
#include "std_testcase.h"
#include <assert.h>
void f106276()
{
    if(GLOBAL_CONST_TRUE)
    {
        assert(0); 
    }
}
