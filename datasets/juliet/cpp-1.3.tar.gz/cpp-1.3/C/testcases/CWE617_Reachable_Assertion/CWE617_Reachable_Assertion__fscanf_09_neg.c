
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106324()
{
    int data;
    data = -1;
    if(GLOBAL_CONST_TRUE)
    {
        fscanf(stdin, "%d", &data);
    }
    assert(data > ASSERT_VALUE);
}
