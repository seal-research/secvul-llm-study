
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106497()
{
    int data;
    data = -1;
    fscanf(stdin, "%d", &data);
    {
        int dataCopy = data;
        int data = dataCopy;
        assert(data > ASSERT_VALUE);
    }
}
