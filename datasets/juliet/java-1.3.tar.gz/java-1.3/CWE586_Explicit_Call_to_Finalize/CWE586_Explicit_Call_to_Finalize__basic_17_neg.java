

public class MyClass extends AbstractTestCase
{
    public void f192955() throws Throwable
    {
        for(int j = 0; j < 1; j++)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192955Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192955Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192955Obj.finalize();
            }
        }
    }
}