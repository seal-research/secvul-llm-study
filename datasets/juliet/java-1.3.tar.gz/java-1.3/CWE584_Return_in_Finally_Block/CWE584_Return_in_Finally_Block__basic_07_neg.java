

public class MyClass extends AbstractTestCase
{
    private int privateFive = 5;
    public void f192799() throws Throwable
    {
        if (privateFive == 5)
        {
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
        }
    }
}