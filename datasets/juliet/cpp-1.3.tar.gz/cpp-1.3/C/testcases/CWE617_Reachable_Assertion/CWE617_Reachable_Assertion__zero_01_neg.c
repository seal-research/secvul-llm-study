
#include "std_testcase.h"
#include <assert.h>
void f106533()
{
    assert(0); 
}
