
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106249()
{
    int data;
    data = -1;
    while(1)
    {
        fscanf(stdin, "%d", &data);
        break;
    }
    assert(data > ASSERT_VALUE);
}
