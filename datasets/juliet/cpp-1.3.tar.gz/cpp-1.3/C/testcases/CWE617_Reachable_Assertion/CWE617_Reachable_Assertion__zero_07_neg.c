
#include "std_testcase.h"
#include <assert.h>
static int staticFive = 5;
void f106262()
{
    if(staticFive==5)
    {
        assert(0); 
    }
}
