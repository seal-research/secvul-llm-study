

public class MyClass extends AbstractTestCase
{
    public void f192674() throws Throwable
    {
        while(true)
        {
            assert "".length() > 0;
            break;
        }
    }
}