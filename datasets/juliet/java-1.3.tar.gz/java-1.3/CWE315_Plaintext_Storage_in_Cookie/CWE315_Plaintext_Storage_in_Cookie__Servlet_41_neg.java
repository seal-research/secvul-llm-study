

import javax.servlet.http.*;
import java.security.MessageDigest;
import java.net.PasswordAuthentication;
public class MyClass extends AbstractTestCaseServlet
{
    private void f193068(String data , HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        response.addCookie(new Cookie("auth", data));
    }
    public void f193069(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        PasswordAuthentication credentials = new PasswordAuthentication("user", "BP@ssw0rd".toCharArray());
        data = credentials.getUserName() + ":" + (new String(credentials.getPassword()));
        f193068(data , request, response );
    }
}