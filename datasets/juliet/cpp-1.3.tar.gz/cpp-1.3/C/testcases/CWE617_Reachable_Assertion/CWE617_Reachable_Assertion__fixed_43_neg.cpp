
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12208
{
static void f106132(int &data)
{
    data = ASSERT_VALUE-1;
}
void f106133()
{
    int data;
    data = -1;
    f106132(data);
    assert(data > ASSERT_VALUE);
}
} 
