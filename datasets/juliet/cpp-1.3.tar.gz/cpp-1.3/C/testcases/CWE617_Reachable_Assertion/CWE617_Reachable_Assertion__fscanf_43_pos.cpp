
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
namespace Test12215
{
static void f250050(int &data)
{
    data = ASSERT_VALUE+1;
}
static void f250051()
{
    int data;
    data = -1;
    f250050(data);
    assert(data > ASSERT_VALUE);
}
void f250053()
{
    f250051();
}
} 
