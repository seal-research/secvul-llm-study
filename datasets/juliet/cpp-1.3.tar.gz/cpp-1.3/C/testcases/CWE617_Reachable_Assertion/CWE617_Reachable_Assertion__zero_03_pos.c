
#include "std_testcase.h"
#include <assert.h>
static void f249916()
{
    if(5!=5)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f249917()
{
    if(5==5)
    {
        assert(1); 
    }
}
void f249915()
{
    f249916();
    f249917();
}
