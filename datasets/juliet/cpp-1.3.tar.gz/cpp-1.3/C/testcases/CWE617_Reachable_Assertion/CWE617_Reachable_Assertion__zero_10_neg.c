
#include "std_testcase.h"
#include <assert.h>
void f106059()
{
    if(globalTrue)
    {
        assert(0); 
    }
}
