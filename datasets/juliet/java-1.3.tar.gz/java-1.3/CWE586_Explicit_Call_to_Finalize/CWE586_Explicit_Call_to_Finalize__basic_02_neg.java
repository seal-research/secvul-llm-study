

public class MyClass extends AbstractTestCase
{
    public void f192864() throws Throwable
    {
        if (true)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192864Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192864Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192864Obj.finalize();
            }
        }
    }
}