

public class MyClass extends AbstractTestCase
{
    public void f192721() throws Throwable
    {
        if (true)
        {
            assert false; 
        }
    }
}