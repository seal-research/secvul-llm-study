
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106467 = 0;
static int f106468(int data)
{
    if(f106467)
    {
        fscanf(stdin, "%d", &data);
    }
    return data;
}
void f106466()
{
    int data;
    data = -1;
    f106467 = 1; 
    data = f106468(data);
    assert(data > ASSERT_VALUE);
}
