

public class MyClass extends AbstractTestCase
{
    private int privateFive = 5;
    private void f279648() throws Throwable
    {
        if (privateFive != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279650 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279650.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279650 = null;
            }
        }
    }
    private void f279653() throws Throwable
    {
        if (privateFive == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279650 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279650.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279650 = null;
            }
        }
    }
    public void f279658() throws Throwable
    {
        f279648();
        f279653();
    }
}