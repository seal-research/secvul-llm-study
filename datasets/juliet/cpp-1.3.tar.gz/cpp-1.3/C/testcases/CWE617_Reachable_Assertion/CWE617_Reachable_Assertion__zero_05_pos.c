
#include "std_testcase.h"
#include <assert.h>
static int staticTrue = 1; 
static int staticFalse = 0; 
static void f250312()
{
    if(staticFalse)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f250313()
{
    if(staticTrue)
    {
        assert(1); 
    }
}
void f250311()
{
    f250312();
    f250313();
}
