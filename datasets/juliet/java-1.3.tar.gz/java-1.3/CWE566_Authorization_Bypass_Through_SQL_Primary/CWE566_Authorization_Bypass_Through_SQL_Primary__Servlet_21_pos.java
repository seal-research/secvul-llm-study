

import javax.servlet.http.*;
import java.sql.*;
import java.util.logging.Level;
public class MyClass extends AbstractTestCaseServlet
{
    private boolean f279159 = false;
    private String f279160(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        if (f279159)
        {
            data = request.getParameter("id");
        }
        else
        {
            data = null;
        }
        return data;
    }
    private boolean f279166 = false;
    private boolean f279167 = false;
    public void f279168(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        f279168G2B1(request, response);
        f279168G2B2(request, response);
    }
    private void f279168G2B1(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f279166 = false;
        data = f279168G2B1_source(request, response);
        Connection dBConnection = IO.getDBConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int id = 0;
        try
        {
            id = Integer.parseInt(data);
        }
        catch ( NumberFormatException nfx )
        {
            id = -1; 
        }
        try
        {
            preparedStatement = dBConnection.prepareStatement("select * from invoices where uid=?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            IO.writeString("f279163() - result requested: " + data +"\n");
        }
        catch (SQLException exceptSql)
        {
            IO.logger.log(Level.WARNING, "Error executing query", exceptSql);
        }
        finally
        {
            try
            {
                if (resultSet != null)
                {
                    resultSet.close();
                }
            }
            catch (SQLException exceptSql)
            {
                IO.logger.log(Level.WARNING, "Could not close ResultSet", exceptSql);
            }
            try
            {
                if (preparedStatement != null)
                {
                    preparedStatement.close();
                }
            }
            catch (SQLException exceptSql)
            {
                IO.logger.log(Level.WARNING, "Could not close PreparedStatement", exceptSql);
            }
            try
            {
                if (dBConnection != null)
                {
                    dBConnection.close();
                }
            }
            catch (SQLException exceptSql)
            {
                IO.logger.log(Level.WARNING, "Could not close Connection", exceptSql);
            }
        }
    }
    private String f279168G2B1_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f279166)
        {
            data = null;
        }
        else
        {
            data = "10";
        }
        return data;
    }
    private void f279168G2B2(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        f279167 = true;
        data = f279168G2B2_source(request, response);
        Connection dBConnection = IO.getDBConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int id = 0;
        try
        {
            id = Integer.parseInt(data);
        }
        catch ( NumberFormatException nfx )
        {
            id = -1; 
        }
        try
        {
            preparedStatement = dBConnection.prepareStatement("select * from invoices where uid=?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            IO.writeString("f279163() - result requested: " + data +"\n");
        }
        catch (SQLException exceptSql)
        {
            IO.logger.log(Level.WARNING, "Error executing query", exceptSql);
        }
        finally
        {
            try
            {
                if (resultSet != null)
                {
                    resultSet.close();
                }
            }
            catch (SQLException exceptSql)
            {
                IO.logger.log(Level.WARNING, "Could not close ResultSet", exceptSql);
            }
            try
            {
                if (preparedStatement != null)
                {
                    preparedStatement.close();
                }
            }
            catch (SQLException exceptSql)
            {
                IO.logger.log(Level.WARNING, "Could not close PreparedStatement", exceptSql);
            }
            try
            {
                if (dBConnection != null)
                {
                    dBConnection.close();
                }
            }
            catch (SQLException exceptSql)
            {
                IO.logger.log(Level.WARNING, "Could not close Connection", exceptSql);
            }
        }
    }
    private String f279168G2B2_source(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data = null;
        if (f279167)
        {
            data = "10";
        }
        else
        {
            data = null;
        }
        return data;
    }
}