

public class MyClass extends AbstractTestCase
{
    public void f192857() throws Throwable
    {
        if (5 == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f192857Obj = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f192857Obj.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f192857Obj.finalize();
            }
        }
    }
}