

public class MyClass extends AbstractTestCase
{
    public void f192759() throws Throwable
    {
        if (5 == 5)
        {
            assert "".length() > 0;
        }
    }
}