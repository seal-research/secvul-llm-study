
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106223()
{
    int data;
    data = -1;
    data = RAND32();
    {
        int dataCopy = data;
        int data = dataCopy;
        assert(data > ASSERT_VALUE);
    }
}
