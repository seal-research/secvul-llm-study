

public class MyClass extends AbstractTestCase
{
    public void f192823() throws Throwable
    {
        switch (7)
        {
        case 7:
            try
            {
                throw new IllegalArgumentException();
            }
            catch(IllegalArgumentException exceptIllegalArgument)
            {
                IO.writeLine("preventing incidental issues");
            }
            finally
            {
                if(true)
                {
                    return; 
                }
            }
            break;
        default:
            IO.writeLine("Benign, fixed string");
            break;
        }
    }
}