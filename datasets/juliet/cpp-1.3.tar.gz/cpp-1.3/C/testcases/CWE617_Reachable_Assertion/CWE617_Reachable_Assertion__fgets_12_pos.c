
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)
static void f250317()
{
    int data;
    data = -1;
    if(globalReturnsTrueOrFalse())
    {
        data = ASSERT_VALUE+1;
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250316()
{
    f250317();
}
