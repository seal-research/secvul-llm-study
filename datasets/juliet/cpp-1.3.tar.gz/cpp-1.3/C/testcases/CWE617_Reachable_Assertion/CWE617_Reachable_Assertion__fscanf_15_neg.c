
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
void f106142()
{
    int data;
    data = -1;
    switch(6)
    {
    case 6:
        fscanf(stdin, "%d", &data);
        break;
    default:
        printLine("Benign, fixed string");
        break;
    }
    assert(data > ASSERT_VALUE);
}
