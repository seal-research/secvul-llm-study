
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f249878 = 0;
static int f249879 = 0;
static int f249880(int data)
{
    if(f249878)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    return data;
}
static void f249882()
{
    int data;
    data = -1;
    f249878 = 0; 
    data = f249880(data);
    assert(data > ASSERT_VALUE);
}
static int f249885(int data)
{
    if(f249879)
    {
        data = ASSERT_VALUE+1;
    }
    return data;
}
static void f249887()
{
    int data;
    data = -1;
    f249879 = 1; 
    data = f249885(data);
    assert(data > ASSERT_VALUE);
}
void f249877()
{
    f249882();
    f249887();
}
