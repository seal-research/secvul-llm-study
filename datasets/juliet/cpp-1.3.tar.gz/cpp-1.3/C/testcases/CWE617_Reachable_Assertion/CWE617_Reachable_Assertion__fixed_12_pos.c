
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static void f250005()
{
    int data;
    data = -1;
    if(globalReturnsTrueOrFalse())
    {
        data = ASSERT_VALUE+1;
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250004()
{
    f250005();
}
