
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static const int STATIC_CONST_FIVE = 5;
static void f250093()
{
    int data;
    data = -1;
    if(STATIC_CONST_FIVE!=5)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
static void f250094()
{
    int data;
    data = -1;
    if(STATIC_CONST_FIVE==5)
    {
        data = ASSERT_VALUE+1;
    }
    assert(data > ASSERT_VALUE);
}
void f250092()
{
    f250093();
    f250094();
}
