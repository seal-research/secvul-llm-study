
#include "std_testcase.h"
#include <assert.h>
static const int STATIC_CONST_TRUE = 1; 
static const int STATIC_CONST_FALSE = 0; 
static void f249642()
{
    if(STATIC_CONST_FALSE)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f249643()
{
    if(STATIC_CONST_TRUE)
    {
        assert(1); 
    }
}
void f249641()
{
    f249642();
    f249643();
}
