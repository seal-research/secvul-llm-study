

public class MyClass extends AbstractTestCase
{
    private void f279394() throws Throwable
    {
        if (false)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            assert "cwe617".length() > 0;
        }
    }
    private void f279396() throws Throwable
    {
        if (true)
        {
            assert "cwe617".length() > 0;
        }
    }
    public void f279398() throws Throwable
    {
        f279394();
        f279396();
    }
}