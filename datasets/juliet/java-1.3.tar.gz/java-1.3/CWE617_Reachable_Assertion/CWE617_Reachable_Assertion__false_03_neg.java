

public class MyClass extends AbstractTestCase
{
    public void f192729() throws Throwable
    {
        if (5 == 5)
        {
            assert false; 
        }
    }
}