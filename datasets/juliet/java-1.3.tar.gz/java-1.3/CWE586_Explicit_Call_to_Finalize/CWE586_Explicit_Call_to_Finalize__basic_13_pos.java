

public class MyClass extends AbstractTestCase
{
    private void f279586() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE != 5)
        {
            IO.writeLine("Benign, fixed string");
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279588 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279588.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279588 = null;
            }
        }
    }
    private void f279591() throws Throwable
    {
        if (IO.STATIC_FINAL_FIVE == 5)
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279588 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279588.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279588 = null;
            }
        }
    }
    public void f279596() throws Throwable
    {
        f279586();
        f279591();
    }
}