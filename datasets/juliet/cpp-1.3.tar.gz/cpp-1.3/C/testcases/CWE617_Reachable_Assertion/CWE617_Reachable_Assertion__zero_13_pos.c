
#include "std_testcase.h"
#include <assert.h>
static void f249739()
{
    if(GLOBAL_CONST_FIVE!=5)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f249740()
{
    if(GLOBAL_CONST_FIVE==5)
    {
        assert(1); 
    }
}
void f249738()
{
    f249739();
    f249740();
}
