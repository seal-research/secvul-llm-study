

public class MyClass extends AbstractTestCase
{
    private void f279625() throws Throwable
    {
        if (IO.staticReturnsTrueOrFalse())
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279627 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279627.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279627 = null;
            }
        }
        else
        {
            CWE586_Explicit_Call_to_Finalize__basic_Helper f279627 = new CWE586_Explicit_Call_to_Finalize__basic_Helper();
            try
            {
                f279627.sayHello();
            }
            catch (Exception exception)
            {
                IO.writeLine("An error occurred.");
            }
            finally
            {
                f279627 = null;
            }
        }
    }
    public void f279633() throws Throwable
    {
        f279625();
    }
}