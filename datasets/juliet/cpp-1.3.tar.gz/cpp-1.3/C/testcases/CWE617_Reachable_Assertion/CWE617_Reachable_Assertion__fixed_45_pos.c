
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f250386Data;
static int f250387G2BData;
static void f250391()
{
    int data = f250387G2BData;
    assert(data > ASSERT_VALUE);
}
static void f250392()
{
    int data;
    data = -1;
    data = ASSERT_VALUE+1;
    f250387G2BData = data;
    f250391();
}
void f250387()
{
    f250392();
}
