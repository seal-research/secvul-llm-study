
#include "std_testcase.h"
#include <assert.h>
static void f249580()
{
    if(false)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        assert(1); 
    }
}
static void f249581()
{
    if(true)
    {
        assert(1); 
    }
}
void f249579()
{
    f249580();
    f249581();
}
