

import javax.servlet.http.*;
import java.security.MessageDigest;
import java.net.PasswordAuthentication;
public class MyClass extends AbstractTestCaseServlet
{
    public void f193060(HttpServletRequest request, HttpServletResponse response) throws Throwable
    {
        String data;
        while (true)
        {
            PasswordAuthentication credentials = new PasswordAuthentication("user", "BP@ssw0rd".toCharArray());
            data = credentials.getUserName() + ":" + (new String(credentials.getPassword()));
            break;
        }
        while (true)
        {
            response.addCookie(new Cookie("auth", data));
            break;
        }
    }
}