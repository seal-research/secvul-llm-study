

public class MyClass extends AbstractTestCase
{
    private void f279256() throws Throwable
    {
        while(true)
        {
            assert true; 
            break;
        }
    }
    public void f279258() throws Throwable
    {
        f279256();
    }
}