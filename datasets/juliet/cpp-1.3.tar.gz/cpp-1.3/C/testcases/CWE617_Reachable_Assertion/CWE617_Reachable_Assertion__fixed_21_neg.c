
#include "std_testcase.h"
#include <assert.h>
#define ASSERT_VALUE 5
static int f106122 = 0;
static int f106123(int data)
{
    if(f106122)
    {
        data = ASSERT_VALUE-1;
    }
    return data;
}
void f106121()
{
    int data;
    data = -1;
    f106122 = 1; 
    data = f106123(data);
    assert(data > ASSERT_VALUE);
}
