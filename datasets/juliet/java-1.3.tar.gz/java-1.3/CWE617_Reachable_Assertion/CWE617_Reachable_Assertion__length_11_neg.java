

public class MyClass extends AbstractTestCase
{
    public void f192689() throws Throwable
    {
        if (IO.staticReturnsTrue())
        {
            assert "".length() > 0;
        }
    }
}